"""Geometry checks for the Concept A OpenVSP model against RFP limits and the sizing model."""
import math
import numpy as np
import openvsp_config
openvsp_config.LOAD_GRAPHICS = False
import openvsp as vsp
from render import meshes
from build_concept_a import P, S_w, b_w, cr_w, ct_w, SZ
from sizing_port import W_TO, W_energy


def extents(ms, skip=()):
    pts = np.vstack([t.reshape(-1, 3) for k, t in ms.items() if k not in skip])
    return pts.min(0), pts.max(0)


def proj_area_xy(ms, names, res=0.05):
    """Planform (top-view) projected area by rasterising triangles onto a grid."""
    tris = np.vstack([ms[n] for n in names if n in ms])[:, :, :2]
    lo, hi = tris.reshape(-1, 2).min(0), tris.reshape(-1, 2).max(0)
    nx, ny = int((hi[0] - lo[0]) / res) + 2, int((hi[1] - lo[1]) / res) + 2
    grid = np.zeros((nx, ny), bool)
    gx = lo[0] + (np.arange(nx) + 0.5) * res
    gy = lo[1] + (np.arange(ny) + 0.5) * res
    for t in tris:
        x0, y0 = t.min(0); x1, y1 = t.max(0)
        i0, i1 = int((x0 - lo[0]) / res), int((x1 - lo[0]) / res) + 1
        j0, j1 = int((y0 - lo[1]) / res), int((y1 - lo[1]) / res) + 1
        X, Y = np.meshgrid(gx[i0:i1], gy[j0:j1], indexing="ij")
        a, b, c = t
        d = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1])
        if abs(d) < 1e-12:
            continue
        l1 = ((b[1] - c[1]) * (X - c[0]) + (c[0] - b[0]) * (Y - c[1])) / d
        l2 = ((c[1] - a[1]) * (X - c[0]) + (a[0] - c[0]) * (Y - c[1])) / d
        grid[i0:i1, j0:j1] |= (l1 >= 0) & (l2 >= 0) & (l1 + l2 <= 1)
    return grid.sum() * res * res


OML = ["Fuselage", "Wing_Inner", "Wing_Outer_Fold", "Horizontal_Tail", "Vertical_Tails", "Chine_Inlet"]
mu = meshes("ConceptA_unfolded.vsp3")
mf = meshes("ConceptA_folded.vsp3")
lo_u, hi_u = extents(mu)
lo_f, hi_f = extents(mf)
ground = P["ground_z"]

print("=== RFP geometric limits ===")
L_oa = hi_u[0] - lo_u[0] - 0.0
L_oa = max(t[:, :, 0].max() for k, t in mu.items() if k in OML) - 0.0
print(f"Overall length (OML)        {L_oa:6.1f} ft   limit: <= F-35C length (~51.4 ft)")
print(f"Span unfolded               {hi_u[1]-lo_u[1]:6.1f} ft   limit 60")
span_f = max(t[:, :, 1].max() for k, t in mf.items() if k in OML) * 2
print(f"Span folded                 {span_f:6.1f} ft   limit 35")
h_f = max(t[:, :, 2].max() for k, t in mf.items() if k in OML) - ground
print(f"Height folded (on gear)     {h_f:6.1f} ft   limit 18.5")
A_u = proj_area_xy(mu, OML); A_f = proj_area_xy(mf, OML)
print(f"Planform projected area     unfolded {A_u:6.0f} ft^2, folded {A_f:6.0f} ft^2")
print(f"Folded footprint rectangle  {L_oa:.1f} x {span_f:.1f} = {L_oa*span_f:6.0f} ft^2  (divide by F/A-18E/F reference for spot factor)")

print("\n=== Planform alignment (plan-view edge angles measured from the mesh) ===")
def plan_edge(name, y_lo, y_hi, edge="LE"):
    t = mu[name].reshape(-1, 3); t = t[t[:, 1] > 0]
    out = []
    ys_av = np.unique(np.round(t[:, 1], 2))
    for yy in (y_lo, y_hi):
        yy = ys_av[np.argmin(np.abs(ys_av - yy))]
        band = t[np.abs(t[:, 1] - yy) < 0.02]
        out.append((band[:, 0].min() if edge == "LE" else band[:, 0].max(), yy))
    (x0, y0), (x1, y1) = out
    return math.degrees(math.atan2(x1 - x0, y1 - y0))
semi = b_w / 2
tw = mu["Wing_Inner"].reshape(-1, 3)
rows = [("Wing LE (inboard of fold)", plan_edge("Wing_Inner", 5.0, P["fold_y"] - 0.3)),
        ("Wing LE (outer panel)", plan_edge("Wing_Outer_Fold", P["fold_y"] + 0.3, semi - 0.3)),
        ("Wing TE", plan_edge("Wing_Inner", 5.0, P["fold_y"] - 0.3, "TE")),
        ("Horizontal tail LE", plan_edge("Horizontal_Tail", 2.6, mu["Horizontal_Tail"][:, :, 1].max() - 0.3)),
        ("Horizontal tail TE", plan_edge("Horizontal_Tail", 2.6, mu["Horizontal_Tail"][:, :, 1].max() - 0.3, "TE")),
        ("Vertical tail LE (projected)", plan_edge("Vertical_Tails", P["vt_y"] + 0.3, mu["Vertical_Tails"][:, :, 1].max() - 0.15)),
        ("Vertical tail TE (projected)", plan_edge("Vertical_Tails", P["vt_y"] + 0.3, mu["Vertical_Tails"][:, :, 1].max() - 0.15, "TE"))]
import trimesh as _tm
_v = mu["Chine_Inlet"].reshape(-1, 3)
_m = _tm.Trimesh(vertices=_v, faces=np.arange(len(_v)).reshape(-1, 3)); _m.merge_vertices()
_u, _c = np.unique(_m.edges_sorted, axis=0, return_counts=True)
_bp = _m.vertices[np.unique(_u[_c == 1])]                      # open-boundary vertices (mouth + aft end)
_bp = _bp[(_bp[:, 1] > 0) & (_bp[:, 0] < _bp[:, 0].min() + 3)]  # right-side mouth loop
slope = np.polyfit(_bp[:, 1], _bp[:, 0], 1)[0]
yy, xx = [0, 1], [0, slope]
rows.append(("Inlet lip (plan view)", math.degrees(math.atan2(xx[1] - xx[0], yy[1] - yy[0]))))
for n, a in rows:
    print(f"  {n:32s} {a:6.1f} deg")

print("\n=== Inlet capture (measured from the mesh: open mouth boundary loop, projected frontal) ===")
_sel = [e for e in _u[_c == 1] if _m.vertices[e, 0].max() < P["inlet_x"] + 2.5 and _m.vertices[e, 1].min() > 0]
_pts = _m.vertices[np.unique(np.array(_sel))]
_ang = np.arctan2(_pts[:, 2] - _pts[:, 2].mean(), _pts[:, 1] - _pts[:, 1].mean()); _o = np.argsort(_ang)
_y, _z = _pts[_o, 1], _pts[_o, 2]
A_cap_each = 0.5 * abs(np.dot(_y, np.roll(_z, -1)) - np.dot(_z, np.roll(_y, -1)))
A_thr = 2 * math.pi / 4 * P["duct_d_throat"] ** 2
print(f"  capture {A_cap_each:.2f} ft^2 per inlet, {2*A_cap_each:.2f} total (target {P['inlet_capture_ft2']:.2f}); "
      f"throat {A_thr:.2f} ft^2; F414 face {P['engine_face_area_ft2']:.2f} ft^2; face/throat {P['engine_face_area_ft2']/A_thr:.2f}")
ad = P["aux_door"]
print(f"  aux blow-in doors: {ad['n_per_side']*2} x {ad['L']}x{ad['h']} ft = {ad['L']*ad['h']*ad['n_per_side']*2:.1f} ft^2 open area")

print("\n=== Sizing-model consistency ===")
print(f"Wing ref area {S_w:.1f} ft^2 (W/S {W_TO/S_w:.0f} psf), span {b_w:.2f}, cr {cr_w:.2f}, ct {ct_w:.2f}, AR {b_w**2/S_w:.2f}")
print(f"Fuselage L {SZ['L_fus']} ft (model {max(mu['Fuselage'][:,:,0].ravel()):.1f}), max width {SZ['W_fus']} (model {2*mu['Fuselage'][:,:,1].max():.2f}), depth {SZ['D_fus']} (model {mu['Fuselage'][:,:,2].max()-mu['Fuselage'][:,:,2].min():.2f})")
print(f"Duct length {SZ['L_duct']} ft, engine F414 D {SZ['D_ft']} L {SZ['L_ft']}")
print(f"Main oleo extended {P['main_oleo_ext_in']:.0f} in (sizing L_mlg {SZ['L_mlg_in']:.0f} in); "
      f"nose oleo extended {P['nose_oleo_ext_in']:.0f} in (sizing L_nlg {SZ['L_nlg_in']:.0f} in -> update sizing input)")
print("\n=== Fuel volume (JP-5 6.8 lb/gal) ===")
need_ft3 = W_energy / 6.8 / 7.48
FILL = 0.90          # usable fraction of a box tank (structure, plumbing, ullage)
rows, tot, mom = [], 0.0, 0.0
for name, t, sym in P["tanks"]:
    v = t["L"] * t["w"] * t["h"] * FILL * (2 if sym else 1)
    rows.append((name, v)); tot += v; mom += v * (t["x"] + t["L"] / 2)
def chord(y): return cr_w - (cr_w - ct_w) * y / (b_w / 2)
def tc(y): return P["tc_root"] + (P["tc_tip"] - P["tc_root"]) * y / (b_w / 2)
c0, c1 = P["wing_tank_chord"]
ys = np.linspace(SZ["W_fus"] / 2, P["fold_y"], 200)
area = (c1 - c0) * chord(ys) * 0.85 * tc(ys) * chord(ys)
v_wing = 2 * np.trapezoid(area, ys) * 0.85
tanLE = math.tan(math.radians(SZ["sweep_c4"])) + (1 / SZ["AR"]) * (1 - SZ["taper"]) / (1 + SZ["taper"])
x_wing = np.trapezoid(area * (P["wing_x"] + ys * tanLE + (c0 + c1) / 2 * chord(ys)), ys) / np.trapezoid(area, ys)
rows.append(("Wing box (15-70% chord, inboard of fold)", v_wing)); tot += v_wing; mom += v_wing * x_wing
for n, v in rows:
    print(f"  {n:42s} {v:6.1f} ft^3")
print(f"  {'TOTAL usable':42s} {tot:6.1f} ft^3 = {tot*7.48*6.8:,.0f} lb  vs required {need_ft3:.1f} ft^3 ({W_energy:.0f} lb) "
      f"-> {tot/need_ft3*100:.0f}%")
print(f"  Fuel centroid x = {mom/tot:.1f} ft (CG estimate {P['cg'][0]} ft, wing 25% MAC 25.2 ft)")

print("\n=== Internal interference (mesh containment) ===")
import trimesh
def tm(name):
    t = mu[name]; v = t.reshape(-1, 3)
    m = trimesh.Trimesh(vertices=v, faces=np.arange(len(v)).reshape(-1, 3), process=True)
    m.merge_vertices(); return m
internal = [n for n in mu if n.startswith(("Fuel_", "Weapons_Bay", "Avionics", "Sensor", "Engine")) or n.endswith("_Well")]
fus = tm("Fuselage")
rng = np.random.default_rng(0)
issues = 0
for n in internal:
    m = tm(n)
    pts = m.sample(3000)
    if n == "Weapons_Bay":           # bay floor is the door line (flush with skin)
        pts = pts[pts[:, 2] > pts[:, 2].min() + 0.15]
    out = (~fus.contains(pts)).mean()
    if out > 0.01:
        print(f"  {n}: {out*100:.1f}% of surface outside fuselage skin"); issues += 1
duct_pts = mu["S_Duct"].reshape(-1, 3)
for i, a in enumerate(internal):
    ma = tm(a)
    if not ma.is_watertight:
        continue
    hit = ma.contains(duct_pts).mean()
    if hit > 0.002:
        print(f"  S_Duct penetrates {a}: {hit*100:.1f}% of duct surface points"); issues += 1
    for b in internal[i + 1:]:
        mb = tm(b)
        pts = mb.sample(3000)
        if ma.contains(pts).mean() > 0.002:
            print(f"  {a} overlaps {b}"); issues += 1
print(f"  {issues} interference issue(s) found among {len(internal)} internal items + ducts")

print("\n=== Carrier landing gear ===")
import gear_sizing as G
r = G.RESULTS
print(f"  Design sink speed 22 ft/s (carrier) vs 10 ft/s (land): energy x{r['E_navy']/r['E_land']:.1f}, "
      f"stroke {r['S_navy']:.1f} in vs {r['S_land']:.1f} in")
print(f"  Main: {P['main_tire'][0]:.0f}x{P['main_tire'][1]} in tire, stroke {P['main_stroke_in']:.0f} in, "
      f"oleo {P['main_oleo_ext_in']:.0f} in extended, cant {P['main_cant_deg']:.0f} deg, track {2*P['main_gear_y']:.0f} ft")
print(f"  Nose: dual {P['nose_tire'][0]:.0f}x{P['nose_tire'][1]} in, stroke {P['nose_stroke_in']:.0f} in, "
      f"oleo {P['nose_oleo_ext_in']:.0f} in extended, launch bar + holdback")
cgx, cgy, cgz = P["cg"]
h_cg = cgz - ground
xm, ym, xn = P["main_gear_x"], P["main_gear_y"], P["nose_gear_x"]
print(f"  CG height above deck (static) {h_cg:.1f} ft, wheelbase {xm-xn:.1f} ft")
print(f"  Tip-back angle      {math.degrees(math.atan((xm-cgx)/h_cg)):5.1f} deg  (want >= ~15-20)")
a = math.atan(ym / (xm - xn)); d = (cgx - xn) * math.sin(a)
print(f"  Turnover angle      {math.degrees(math.atan(h_cg/d)):5.1f} deg  (Raymer: <= 54 carrier)")
print(f"  Nose static load    {(xm-cgx)/(xm-xn)*100:5.1f} %   (typical 8-15 %)")
X = np.concatenate([mu[k][:, :, 0].ravel() for k in ("Fuselage", "Horizontal_Tail", "Vertical_Tails")])
Z = np.concatenate([mu[k][:, :, 2].ravel() for k in ("Fuselage", "Horizontal_Tail", "Vertical_Tails")])
m = X > xm + 1
print(f"  Tail-down angle     {np.degrees(np.arctan2(Z[m]-ground, X[m]-xm)).min():5.1f} deg  (rotation about main wheels)")
mh = mu["Arresting_Hook"].reshape(-1, 3)
print(f"  Hook point x={mh[:,0].max():.1f} ft ({mh[:,0].max()-xm:.1f} ft aft of mains), {mh[:,2].min()-ground:+.2f} ft vs deck")
