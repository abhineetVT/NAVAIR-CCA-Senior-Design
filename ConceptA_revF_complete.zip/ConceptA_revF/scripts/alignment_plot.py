import math, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
import render
from build_concept_a import P, b_w, cr_w, ct_w, tanLE_w, SZ
ms = render.meshes("ConceptA_unfolded.vsp3")
OML = ["Fuselage", "Wing_Inner", "Wing_Outer_Fold", "Horizontal_Tail", "Vertical_Tails", "Chine_Inlet"]
fig, ax = plt.subplots(figsize=(13, 9), dpi=120)
for k in OML:
    ax.add_collection(PolyCollection(ms[k][:, :, :2] * [1, -1], facecolors=[(0.72, 0.74, 0.78, 0.55)], edgecolors="none"))
tanTE = tanLE_w - (4 / SZ["AR"]) * (1 - SZ["taper"]) / (1 + SZ["taper"])
LE, TE = math.degrees(math.atan(tanLE_w)), math.degrees(math.atan(tanTE))
def edge_lines(name, which):
    """Root-to-tip straight line through the extreme LE (min x) or TE (max x) points of each side."""
    t = ms[name].reshape(-1, 3); segs = []
    for sgn in (1, -1):
        tt = t[t[:, 1] * sgn > 0.05]
        ys = np.unique(np.round(np.abs(tt[:, 1]), 2))
        y_in, y_out = ys[min(2, len(ys) - 1)], ys[-1]
        pts = []
        for y in (y_in, y_out):
            band = tt[np.abs(np.abs(tt[:, 1]) - y) < 0.02]
            pts.append((band[:, 0].min() if which == "LE" else band[:, 0].max(), -sgn * y))
        segs.append((np.array([pts[0][0], pts[1][0]]), np.array([pts[0][1], pts[1][1]])))
    return segs
for name in ("Wing_Inner", "Wing_Outer_Fold", "Horizontal_Tail", "Vertical_Tails"):
    for x, y in edge_lines(name, "LE"): ax.plot(x, y, color="#D85A30", lw=2.6)
    for x, y in edge_lines(name, "TE"): ax.plot(x, y, color="#1D9E75", lw=2.6)
import trimesh
v = ms["Chine_Inlet"].reshape(-1, 3); m = trimesh.Trimesh(vertices=v, faces=np.arange(len(v)).reshape(-1, 3)); m.merge_vertices()
u, c = np.unique(m.edges_sorted, axis=0, return_counts=True)
for e in u[c == 1]:
    p = m.vertices[e]
    if p[:, 0].max() < P["inlet_x"] + 2.5: ax.plot(p[:, 0], -p[:, 1], color="#D85A30", lw=2.6)
ax.plot([], [], color="#D85A30", lw=3, label=f"Leading edges + inlet lips: all {LE:.1f} deg sweep")
ax.plot([], [], color="#1D9E75", lw=3, label=f"Trailing edges: all {TE:.1f} deg sweep")
for x0, y0 in ((6, 13), (6, -13)):
    pass
ax.set_aspect("equal"); ax.grid(alpha=0.25); ax.set_xlabel("x from nose (ft)"); ax.set_ylabel("y (ft)")
ax.set_title("Concept A rev E: planform alignment (plan view, measured from the OpenVSP mesh)", fontsize=13)
ax.legend(loc="lower left", fontsize=11)
fig.tight_layout(); fig.savefig("ConceptA_revE_alignment.png")
