import sys, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
sys.path.insert(0, "/home/claude/cca")
import inlet_trade as T
res = T.sweep(caps=np.linspace(4.45, 8.7, 86))
A = np.array([r["Ac"] for r in res])
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]
INK, MUTED, GRID = "#2b2b2a", "#6b6a66", "#e6e5e1"
CUR, REC, BAND = T.A_CAP0, 5.7, (4.8, 5.2)
plt.rcParams.update({"font.size": 10, "axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": MUTED,
                     "ytick.color": MUTED, "axes.spines.top": False, "axes.spines.right": False})
fig, axs = plt.subplots(2, 2, figsize=(14, 9), dpi=130)
def series(ax, keys, labels, styles, min_gap_pts=11):
    ends = []
    for i, (k, lab, ls) in enumerate(zip(keys, labels, styles)):
        y = np.array([r[k] for r in res])
        ax.plot(A, y, color=C[i], lw=2, ls=ls)
        ends.append([y[-1], lab, i])
    fig.canvas.draw()
    to_pts = lambda v: ax.transData.transform((A[-1], v))[1] * 72 / fig.dpi
    ends.sort(key=lambda e: e[0])
    placed = []
    for yv, lab, i in ends:
        py = to_pts(yv)
        if placed and py - placed[-1] < min_gap_pts:
            py = placed[-1] + min_gap_pts
        placed.append(py)
        ax.annotate(lab, (A[-1], yv), xytext=(8, py - to_pts(yv)), textcoords="offset points", va="center",
                    color=INK, fontsize=9, arrowprops=dict(arrowstyle="-", color=C[i], lw=1))
def frame(ax, title, ylab):
    ax.axvspan(*BAND, color="#2a78d6", alpha=0.07, lw=0)
    ax.annotate("strict-criteria\nband 4.8–5.2", ((BAND[0] + BAND[1]) / 2, 0.02), xycoords=("data", "axes fraction"),
                ha="center", va="bottom", fontsize=8, color=MUTED)
    for x, lab in ((CUR, "rev E now\n7.76 ft²"), (REC, "recommended\n5.7 ft²")):
        ax.axvline(x, color=MUTED, lw=1, ls=":")
        ax.annotate(lab, (x, 1.0), xycoords=("data", "axes fraction"), xytext=(3, -2), textcoords="offset points",
                    va="top", fontsize=8.5, color=MUTED)
    ax.set_title(title, loc="left", color=INK, fontsize=11)
    ax.set_ylabel(ylab); ax.grid(color=GRID, lw=0.8); ax.set_xlim(4.4, 10.4)
    ax.set_xlabel("total inlet capture area, both inlets (ft²)  —  throat = capture / 1.25")
ax = axs[0, 0]
ax.axhspan(0.6, 0.85, color="#1baf7a", alpha=0.08, lw=0)
ax.annotate("efficient cruise band 0.6–0.85", (4.45, 0.86), fontsize=8.5, color=MUTED)
series(ax, ["mfr_cruise", "mfr_dash", "mfr_combat", "mfr_wo"], ["cruise 30k M0.7", "dash 30k M0.85", "combat 10k M0.6 AB", "wave-off 145 kt AB"], ["-", "--", "-.", ":"])
ax.axhline(1.0, color=MUTED, lw=0.8)
frame(ax, "Mass-flow ratio A₀/A_c  (<1 spills air, >1 sucks air round the lips)", "A₀ / A_capture")
ax = axs[0, 1]
y = np.array([r["mt_max"] for r in res]); ax.plot(A, y, color=C[0], lw=2)
ax.annotate("throat Mach at max airflow", (A[-1], y[-1]), xytext=(6, 0), textcoords="offset points", va="center", fontsize=9, color=INK)
ax.axhline(0.65, color=MUTED, lw=0.8, ls="--"); ax.annotate("design limit ~0.65", (4.45, 0.66), fontsize=8.5, color=MUTED)
ax.axhline(0.42, color=MUTED, lw=0.8, ls=":"); ax.annotate("F414 face Mach 0.42 (fixed by engine)", (4.45, 0.43), fontsize=8.5, color=MUTED)
frame(ax, "Throat Mach number at max airflow (choke = 1.0)", "Mach"); ax.set_ylim(0.25, 1.05)
ax = axs[1, 0]
series(ax, ["dT_cruise", "dT_combat", "dT_wo_b", "dT_static_b"], ["cruise", "combat (max AB)", "wave-off (aux doors)", "catapult static (aux doors)"], ["-", "--", "-.", ":"])
frame(ax, "Installed thrust loss from inlet recovery (Raymer, C_ram 1.35)", "thrust loss (%)"); ax.set_ylim(0, 10)
ax = axs[1, 1]
y = np.array([r["diff"] for r in res]); ax.plot(A, y, color=C[0], lw=2)
ax.annotate("F414 face / throat area", (A[-1], y[-1]), xytext=(6, 0), textcoords="offset points", va="center", fontsize=9, color=INK)
ax.axhspan(1.05, 1.40, color="#1baf7a", alpha=0.08, lw=0); ax.annotate("good subsonic diffuser 1.05–1.40", (4.45, 1.41), fontsize=8.5, color=MUTED)
ax.axhline(1.0, color=MUTED, lw=0.8); ax.annotate("<1 = duct contracts (rev E today)", (8.0, 0.93), fontsize=8.5, color=MUTED)
frame(ax, "Duct diffusion ratio (engine face area / throat area)", "area ratio")
fig.suptitle("Concept A rev E — inlet/F414 airflow matching trade (F414-GE-400: 170 lb/s, 31 in face)", x=0.01, ha="left", fontsize=13, color=INK)
fig.tight_layout(); fig.savefig("ConceptA_inlet_trade.png")
