"""Line-for-line Python port of cca_sizing_model.m (NAVAIR-CCA-Senior-Design, main @ Oct 1 2026).
Used only to read the closure point and derived geometry so the OpenVSP model matches it."""
import math
import numpy as np

cosd = lambda a: math.cos(math.radians(a))
d = dict(WS_TO=100, AR=4.0, taper=0.25, sweep_c4=35, tc_root=0.10, Sct_frac=0.14, Sht_ratio=0.18,
         Svt_ratio=0.14, Nvt=2, Lt=18, L_fus=46, D_fus=6.0, W_fus=8.5, k_fus_wet=0.80, bay_door_ft2=60,
         L_mlg_in=60, L_nlg_in=55, N_gear_limit=5.0, L_duct=20, K_duct=2.5, Nz_limit=5.0, FoS=1.5,
         T_max_SL=22000, W_dry=2445, D_ft=2.92, L_ft=12.9, sfc_max=1.6, W_avionics=1000, W_autonomy=300,
         Rkva=120, N_fc_sys=4, N_hyd_func=12, N_tanks=4, protected_frac=0.5, growth=0.10, f_wing=0.85,
         f_tail=0.83, f_fus=0.90, f_gear=0.95, f_inlet=0.85, k_bay_fus=1.08, door_lb_ft2=4.0, RAM_lb_ft2=0.15,
         k_carrier_fus=1.07, k_carrier_gear=1.20, wing_fold_frac=0.05, W_hook=350, n_hardpoints=4, W_hardpoint=60)
W_energy, W_payload = 9923.0, 2000.0


def oew(d, W_TO, W_fuel, parts=False):
    Sw = W_TO / d["WS_TO"]; b = math.sqrt(d["AR"] * Sw); cr = 2 * Sw / (b * (1 + d["taper"]))
    Scsw = d["Sct_frac"] * Sw; Sht = d["Sht_ratio"] * Sw; Svt = d["Svt_ratio"] * Sw / d["Nvt"]
    Swet = d["k_fus_wet"] * math.pi * 0.5 * (d["D_fus"] + d["W_fus"]) * d["L_fus"] + 2.04 * (Sw - min(cr * d["W_fus"], 0.6 * Sw)) + 2.04 * (Sht + d["Nvt"] * Svt)
    Nz = d["Nz_limit"] * d["FoS"]; Wdg = W_TO - 0.5 * W_fuel; Wl = W_TO - 0.75 * W_fuel; Nl = 1.5 * d["N_gear_limit"]
    W_wing = 0.0103 * (Wdg * Nz) ** 0.5 * Sw ** 0.622 * d["AR"] ** 0.785 * d["tc_root"] ** -0.4 * (1 + d["taper"]) ** 0.05 / cosd(d["sweep_c4"]) * Scsw ** 0.04 * d["f_wing"]
    W_ht = 3.316 * (1 + 0.5 * d["W_fus"] / math.sqrt(3.5 * Sht)) ** -2 * (Wdg * Nz / 1000) ** 0.260 * Sht ** 0.806 * d["f_tail"]
    W_vt = d["Nvt"] * 0.452 * (Wdg * Nz) ** 0.488 * Svt ** 0.718 * 0.90 ** 0.341 / d["Lt"] * 1.25 ** 0.348 * 1.3 ** 0.223 * 1.4 ** 0.25 / cosd(40) ** 0.323 * d["f_tail"]
    W_fus = 0.499 * Wdg ** 0.35 * Nz ** 0.25 * d["L_fus"] ** 0.5 * d["D_fus"] ** 0.849 * d["W_fus"] ** 0.685 * d["f_fus"]
    W_lg = ((Wl * Nl) ** 0.25 * d["L_mlg_in"] ** 0.973 + (Wl * Nl) ** 0.290 * d["L_nlg_in"] ** 0.5 * 2 ** 0.525) * d["f_gear"]
    Te = d["T_max_SL"]
    W_eng_install = 0.013 * Te ** 0.579 * Nz + 1.13 * math.pi * d["D_ft"] * 0.5 * d["L_ft"] + 0.01 * d["W_dry"] ** 0.717 * Nz + 3.5 * d["D_ft"] * 8 + 4.55 * d["D_ft"] * d["L_ft"] + 37.82 + 10.5 * 20 ** 0.222 + 0.025 * Te ** 0.760
    W_inlet = 13.29 * d["L_duct"] ** 0.643 * d["K_duct"] ** 0.182 * d["D_ft"] * d["f_inlet"]
    Vt = W_fuel / 6.8; Vp = d["protected_frac"] * Vt
    W_fs = 7.45 * Vt ** 0.47 * 2 ** -0.095 * (1 + Vp / Vt) * d["N_tanks"] ** 0.066 * (Te * d["sfc_max"] / 1000) ** 0.249
    Scs = Scsw + 0.3 * Sht + 0.25 * Svt * d["Nvt"]
    W_flt = 36.28 * 0.90 ** 0.003 * Scs ** 0.489 * d["N_fc_sys"] ** 0.484
    W_instr = 8.0 + 36.37 * d["N_tanks"] ** 0.237; W_hyd = 37.23 * d["N_hyd_func"] ** 0.664
    W_elec = 172.2 * 1.45 * d["Rkva"] ** 0.152 * 40 ** 0.10 * 2 ** 0.091
    W_av = d["W_avionics"] + d["W_autonomy"]; W_ecs = 201.6 * (W_av / 1000) ** 0.735
    structure = W_wing + W_ht + W_vt + W_fus + W_lg + d["n_hardpoints"] * d["W_hardpoint"]
    stealth = W_fus * (d["k_bay_fus"] - 1) + d["bay_door_ft2"] * d["door_lb_ft2"] + d["RAM_lb_ft2"] * Swet
    carrier = d["wing_fold_frac"] * W_wing + W_fus * d["k_bay_fus"] * (d["k_carrier_fus"] - 1) + W_lg * (d["k_carrier_gear"] - 1) + d["W_hook"]
    propulsion = d["W_dry"] + W_eng_install + W_inlet + W_fs
    systems = W_flt + W_instr + W_hyd + W_elec + W_av + W_ecs + 3.2e-4 * W_TO
    O = (structure + stealth + carrier + propulsion + systems) * (1 + d["growth"])
    if parts:
        return O, dict(Sw=Sw, b=b, cr=cr, Sht=Sht, Svt_each=Svt, Swet=Swet, W_wing=W_wing, W_ht=W_ht, W_vt=W_vt,
                       W_fus=W_fus, W_lg=W_lg, propulsion=propulsion, systems=systems, structure=structure,
                       stealth=stealth, carrier=carrier)
    return O


W = np.linspace(20000, 50000, 80)
O = np.array([oew(d, w, W_energy) for w in W]); R = W - W_energy - W_payload
i = np.where(np.diff(np.sign(O - R)) != 0)[0][0]
f = O[i:i + 2] - R[i:i + 2]
W_TO = W[i] + (0 - f[0]) * (W[i + 1] - W[i]) / (f[1] - f[0])
OEW, g = oew(d, W_TO, W_energy, parts=True)
# ---------------------------------------------------------------- updated framework override
# If sizing_point_conceptA.json (exported from the team's cca_sizing framework, counter-air
# sizing case) is present, it replaces the legacy closure. Set LEGACY_SIZING=1 to ignore it.
import json as _json, os as _os
SOURCE = "cca_sizing_model.m (legacy, Oct 1)"
TAIL = dict(AR_ht=3.5, tap_ht=0.35, sweep_ht=35.0, AR_vt=1.3, tap_vt=0.40, sweep_vt=40.0)
_sp = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "sizing_point_conceptA.json")
if _os.path.exists(_sp) and not _os.environ.get("LEGACY_SIZING"):
    _pt = _json.load(open(_sp))["counter_air"]
    W_TO, OEW, W_energy = _pt["W_TO"], _pt["OEW"], _pt["W_fuel_total"]
    d.update(WS_TO=_pt["WS"], AR=_pt["AR"], taper=_pt["taper"], sweep_c4=_pt["sweep_c4"],
             tc_root=_pt["tc_root"], Sht_ratio=_pt["S_ht"] / _pt["S_ref"],
             Svt_ratio=_pt["S_vt_total"] / _pt["S_ref"], Nvt=_pt["n_vtail_panels"], L_fus=_pt["l_fus"])
    TAIL = dict(AR_ht=4.0, tap_ht=0.35, sweep_ht=35.0, AR_vt=1.6, tap_vt=0.35, sweep_vt=38.0)  # cca_requirements.json
    TC_TIP = _pt["tc_tip"]
    FOLD_FRACTION = 0.55
    SOURCE = "cca_sizing framework (Nov 15), Concept A geometry, counter-air sizing case"

if __name__ == "__main__":
    print(f"Closure: W_TO = {W_TO:.0f} lb, OEW = {OEW:.0f} lb, OEW/W_TO = {OEW/W_TO:.3f}")
    for k, v in g.items():
        print(f"  {k:12s} {v:9.1f}")
    ct = g["cr"] * d["taper"]
    print(f"  tip chord {ct:.2f} ft, MAC {2/3*g['cr']*(1+d['taper']+d['taper']**2)/(1+d['taper']):.2f} ft")
