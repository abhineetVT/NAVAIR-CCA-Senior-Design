import sys, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
import render
OML = ["Fuselage", "Wing_Inner", "Wing_Outer_Fold", "Horizontal_Tail", "Vertical_Tails", "Chine_Inlet"]
import os
OLD_DIR = os.environ.get("OLD_DIR", "revC"); OLD_LAB = os.environ.get("OLD_LAB", "Rev C"); NEW_LAB = os.environ.get("NEW_LAB", "Rev D"); OUT = os.environ.get("OUT", "ConceptA_revC_vs_revD.png")
old = render.meshes(OLD_DIR + "/ConceptA_unfolded.vsp3"); new = render.meshes("ConceptA_unfolded.vsp3")
fig, axs = plt.subplots(1, 2, figsize=(15, 6.5), dpi=120, gridspec_kw=dict(width_ratios=[1.25, 1]))
for ax, (i, j, title) in zip(axs, [((0, 1), None, "Plan view"), ((0, 2), None, "Side view")]):
    for ms, fc, ec, lab in ((old, (0.85, 0.35, 0.19, 0.18), (0.6, 0.24, 0.11, 0.9), OLD_LAB),
                            (new, (0.33, 0.29, 0.72, 0.30), (0.2, 0.17, 0.5, 0.9), NEW_LAB)):
        polys = [t[:, :, list(i)] * ([1, -1] if i == (0, 1) else [1, 1]) for k, t in ms.items() if k in OML]
        P = np.vstack(polys)
        ax.add_collection(PolyCollection(P, facecolors=[fc], edgecolors="none"))
        ax.plot([], [], color=ec, lw=6, alpha=0.6, label=lab)
    allp = np.vstack([t[:, :, list(i)].reshape(-1, 2) for t in list(old.values()) + list(new.values())])
    ax.set_xlim(allp[:, 0].min() - 1, allp[:, 0].max() + 1)
    ax.set_ylim((-allp[:, 1].max() - 1, -allp[:, 1].min() + 1) if i == (0, 1) else (allp[:, 1].min() - 1, allp[:, 1].max() + 1))
    ax.set_aspect("equal"); ax.grid(alpha=0.3); ax.set_xlabel("x from nose (ft)"); ax.set_title(title)
axs[0].legend(loc="lower left", fontsize=9)
fig.suptitle(os.environ.get("TITLE", "Concept A outer mold line comparison"), fontsize=13)
plt.tight_layout(); fig.savefig(OUT)
