"""
Gobbleworks Team 11 - Concept A (chine-inlet strike CCA) OpenVSP model builder.

Geometry is driven by the team sizing model (cca_sizing_model.m, repo main @ 2026-10-01) through
sizing_port.py, so the wing, tails, fuselage, engine, duct and gear match the sizing closure
(W_TO = 29,028 lb, OEW = 17,105 lb). Change the sizing inputs there and re-run this file.

Run with the OpenVSP 3.56 Python API:
    python build_concept_a.py [outdir]  -> ConceptA_unfolded.vsp3, ConceptA_folded.vsp3

Units: FEET. x aft from nose, y right, z up, fuselage centerline z = 0.
Layout choices that the sizing code does NOT set (positions, fold station, chine shape, CG)
are marked LAYOUT and are first-cut values to refine.
"""
import math
import openvsp_config
openvsp_config.LOAD_GRAPHICS = False
import openvsp as vsp
from sizing_port import d as SZ, W_TO, OEW, W_energy, TAIL, SOURCE
import sizing_port as _SPm
import gear_sizing as G

# ---------------------------------------------------------------- derived from sizing model
S_w = W_TO / SZ["WS_TO"]
b_w = math.sqrt(SZ["AR"] * S_w)
cr_w = 2 * S_w / (b_w * (1 + SZ["taper"]))
ct_w = cr_w * SZ["taper"]
mac_w = 2 / 3 * cr_w * (1 + SZ["taper"] + SZ["taper"] ** 2) / (1 + SZ["taper"])
ymac_w = b_w / 6 * (1 + 2 * SZ["taper"]) / (1 + SZ["taper"])
tanLE_w = math.tan(math.radians(SZ["sweep_c4"])) + (1 / SZ["AR"]) * (1 - SZ["taper"]) / (1 + SZ["taper"])

S_ht = SZ["Sht_ratio"] * S_w            # total, through centerline
AR_ht, tap_ht, sweep_ht = TAIL["AR_ht"], TAIL["tap_ht"], TAIL["sweep_ht"]
S_vt = SZ["Svt_ratio"] * S_w / SZ["Nvt"]  # each
AR_vt, tap_vt, sweep_vt = TAIL["AR_vt"], TAIL["tap_vt"], TAIL["sweep_vt"]

P = dict(
    L_fus=SZ["L_fus"], W_fus=SZ["W_fus"], D_fus=SZ["D_fus"],
    wing_x=25.2 - ymac_w * tanLE_w - 0.25 * mac_w,   # LAYOUT: root LE placed so 25% MAC stays at x = 25.2 ft
    wing_z=-0.8,            # LAYOUT
    fold_y=getattr(_SPm, "FOLD_FRACTION", None) and _SPm.FOLD_FRACTION * b_w / 2 or 9.0,  # wing-fold station
    tc_root=SZ["tc_root"], tc_tip=getattr(_SPm, "TC_TIP", 0.06),
    ht_z=-0.3, vt_y=1.45, vt_z=1.9, vt_cant=25.0,  # LAYOUT (fins root on the narrower faceted top deck)
    nose_end_x=14.0, aft_start_x=29.0, nozzle_w=3.4, nozzle_h=3.0,   # rev E straight-line body breaks
    inlet_lip_trim_deg=0.0,  # verified: lip boundary loop reads exactly the section rotation
    # rev F inlets: total frontal capture 5.70 ft^2 (inlet_trade.py recommendation; rev E measured 7.76 ft^2
    # with inlet_w 2.0 / inlet_h 2.6). Linear scale applied to every inlet section; outer lip kept on the chine.
    inlet_capture_ft2=5.70, inlet_capture_revE_ft2=7.76,
    inlet_z=-0.8,
    duct_throat_area_ft2=5.70 / 1.25,          # contraction capture/throat 1.25 -> M_throat ~0.49 at max airflow
    engine_face_area_ft2=math.pi / 4 * (31.0 / 12) ** 2,   # F414-GE-400 inlet diameter 31 in
    aux_door=dict(x=15.0, L=1.2, h=0.5, z=0.7, n_per_side=2, gap=0.25),   # flush blow-in doors, closed in flight
    engine=dict(L=SZ["L_ft"], d=SZ["D_ft"], z=0.3),
    engine_x=31.5,          # LAYOUT; inlet face = engine face - L_duct
    sensor_nose=dict(x=4.5, L=4.0, w=1.5, h=1.0, z=-0.25),
    avionics=dict(x=8.5, L=5.0, w=3.4, h=1.6, z=0.8),       # with sensor nose: ~1,000 lb mission systems
    bay=dict(x=13.5, L=14.0, w=SZ["bay_door_ft2"] / 14.0, h=2.4, z=-1.6),   # 60 ft^2 of doors
    # fuel tanks (box approximations of integral/bladder tanks)
    tanks=[
        ("Fuel_Dorsal_Fwd", dict(x=13.5, L=2.5, w=3.6, h=1.4, y=0.0, z=1.75), False),
        ("Fuel_Dorsal", dict(x=16.0, L=10.0, w=4.2, h=2.1, y=0.0, z=1.85), False),
        ("Fuel_Carry_Through", dict(x=17.0, L=9.0, w=4.0, h=1.15, y=0.0, z=0.2), False),  # integral wing center box
        ("Fuel_Aft_Saddle", dict(x=26.5, L=5.0, w=5.2, h=1.1, y=0.0, z=2.3), False),
        ("Fuel_Engine_Side", dict(x=32.0, L=3.5, w=0.75, h=2.05, y=2.2, z=0.3), True),
        ("Fuel_Lower_Side", dict(x=16.0, L=10.5, w=1.4, h=1.45, y=3.05, z=-1.975), True),
    ],
    wing_tank_chord=(0.15, 0.70),   # integral wing box tank, fuselage side to fold
    # carrier landing gear (see gear_sizing.py)
    main_gear_x=27.4, main_gear_y=7.0, main_tire=G.MAIN_TIRE,
    main_trunnion=(26.6, 5.8, -1.25), main_stroke_in=G.MAIN_STROKE_IN, main_oleo_ext_in=max(G.MAIN_OLEO_EXT_IN, SZ["L_mlg_in"]),
    nose_gear_x=10.0, nose_tire=G.NOSE_TIRE, nose_trunnion_z=-0.6, nose_stroke_in=G.NOSE_STROKE_IN,
    main_well=dict(x=27.55, L=2.75, w=2.72, h=0.98, y=2.42, z=-2.19),
    nose_well=dict(x=9.15, L=3.45, w=1.6, h=1.7, y=0.0, z=-1.12),
    cg=(24.7, 0.0, 0.0),    # LAYOUT estimate at ~20% MAC; replace with weights-team CG
    hook_pivot=(41.0, -1.6), hook_len=7.4,
)
# static deck height: main oleo compressed 2/3 of stroke at static (Raymer guidance)
_tx, _ty, _tz = P["main_trunnion"]
_L_static = (P["main_oleo_ext_in"] - 2 / 3 * P["main_stroke_in"]) / 12
_dy = P["main_gear_y"] - _ty
_dz = math.sqrt(_L_static ** 2 - _dy ** 2)
P["main_axle_z"] = _tz - _dz
P["ground_z"] = P["main_axle_z"] - P["main_tire"][0] / 24
P["main_cant_deg"] = math.degrees(math.atan2(_dy, _dz))
P["main_strut_len"] = _L_static
P["nose_axle_z"] = P["ground_z"] + P["nose_tire"][0] / 24
P["nose_strut_static"] = P["nose_trunnion_z"] - P["nose_axle_z"]
P["nose_oleo_ext_in"] = P["nose_strut_static"] * 12 + 2 / 3 * P["nose_stroke_in"]
# hook: pivot to deck contact, 18+ ft aft of main gear
_hx, _hz = P["hook_pivot"]
P["hook_deg"] = math.degrees(math.asin((_hz - P["ground_z"]) / P["hook_len"]))
P["inlet_x"] = P["engine_x"] - SZ["L_duct"]
P["inlet_k"] = math.sqrt(P["inlet_capture_ft2"] / P["inlet_capture_revE_ft2"])
P["inlet_w"], P["inlet_h"] = 2.0 * P["inlet_k"], 2.6 * P["inlet_k"]
P["inlet_y"] = 3.2 + (2.0 - P["inlet_w"]) / 2            # keep outer lip edge on the chine
P["duct_d_throat"] = math.sqrt(P["duct_throat_area_ft2"] / 2 * 4 / math.pi)
P["duct_d_face"] = math.sqrt(P["engine_face_area_ft2"] / 2 * 4 / math.pi)   # each duct feeds half the face

SET_OML, SET_INT, SET_GEAR = 3, 4, 5


def sp(gid, name, grp, val):
    vsp.SetParmVal(gid, name, grp, val)


def xs(xsurf, i):
    return vsp.GetXSec(xsurf, i)


def set_xs(x, **kw):
    for k, v in kw.items():
        vsp.SetParmVal(vsp.GetXSecParm(x, k), v)


def straight_skin(x):
    """Zero the default nose/tail tangent angles & curvatures so a section is skinned straight."""
    for p in vsp.GetXSecParmIDs(x):
        n = vsp.GetParmName(p)
        if (n.endswith("Angle") or n.endswith("Curve")) and n[:3] in ("Top", "Bot", "Lef", "Rig"):
            vsp.SetParmVal(p, 0.0)


def set_color(gid, r, g, b):
    vsp.SetGeomWireColor(gid, int(r), int(g), int(b))


def tag(gid, *sets):
    for s in sets:
        vsp.SetSetFlag(gid, s, True)


def place(g, x=0.0, y=0.0, z=0.0, rx=0.0, ry=0.0, rz=0.0):
    sp(g, "X_Rel_Location", "XForm", x); sp(g, "Y_Rel_Location", "XForm", y); sp(g, "Z_Rel_Location", "XForm", z)
    sp(g, "X_Rel_Rotation", "XForm", rx); sp(g, "Y_Rel_Rotation", "XForm", ry); sp(g, "Z_Rel_Rotation", "XForm", rz)


def fuselage_with(name, length, n_xsec):
    g = vsp.AddGeom("FUSELAGE")
    vsp.SetGeomName(g, name)
    sp(g, "Length", "Design", length)
    s = vsp.GetXSecSurf(g, 0)
    while vsp.GetNumXSec(s) < n_xsec:
        vsp.InsertXSec(g, vsp.GetNumXSec(s) - 2, vsp.XS_ROUNDED_RECTANGLE)
    while vsp.GetNumXSec(s) > n_xsec:
        vsp.CutXSec(g, 1)
    return g, s


def box(name, x, L, w, h, y=0.0, z=0.0, r=0.15, sets=(SET_INT,), color=(200, 200, 200), sym=False):
    g, s = fuselage_with(name, L, 4)
    for i in range(4):
        vsp.ChangeXSecShape(s, i, vsp.XS_ROUNDED_RECTANGLE)
        x_ = xs(s, i)
        set_xs(x_, RoundedRect_Width=w, RoundedRect_Height=h, RoundRectXSec_Radius=r, XLocPercent=i / 3.0)
        straight_skin(x_)
    sp(g, "CapUMinOption", "EndCap", vsp.FLAT_END_CAP)
    sp(g, "CapUMaxOption", "EndCap", vsp.FLAT_END_CAP)
    place(g, x, y, z)
    if sym:
        sp(g, "Sym_Planar_Flag", "Sym", vsp.SYM_XZ)
    set_color(g, *color)
    tag(g, *sets)
    return g


def cylinder(name, x, L, dia, y=0.0, z=0.0, ry=0.0, sets=(SET_INT,), color=(150, 150, 150), sym=False):
    g, s = fuselage_with(name, L, 4)
    for i in range(4):
        vsp.ChangeXSecShape(s, i, vsp.XS_CIRCLE)
        set_xs(xs(s, i), Circle_Diameter=dia, XLocPercent=i / 3.0)
        straight_skin(xs(s, i))
    sp(g, "CapUMinOption", "EndCap", vsp.FLAT_END_CAP)
    sp(g, "CapUMaxOption", "EndCap", vsp.FLAT_END_CAP)
    place(g, x, y, z, ry=ry)
    if sym:
        sp(g, "Sym_Planar_Flag", "Sym", vsp.SYM_XZ)
    set_color(g, *color)
    tag(g, *sets)
    return g


def lifting_surface(name, x, y, z, span, c_root, c_tip, sweep, sweep_loc, dihedral, tc_root, tc_tip,
                    color=(170, 175, 185), sets=(SET_OML,)):
    g = vsp.AddGeom("WING")
    vsp.SetGeomName(g, name)
    vsp.SetDriverGroup(g, 1, vsp.SPAN_WSECT_DRIVER, vsp.ROOTC_WSECT_DRIVER, vsp.TIPC_WSECT_DRIVER)
    sp(g, "Span", "XSec_1", span)
    sp(g, "Root_Chord", "XSec_1", c_root)
    sp(g, "Tip_Chord", "XSec_1", c_tip)
    sp(g, "Sweep", "XSec_1", sweep)
    sp(g, "Sweep_Location", "XSec_1", sweep_loc)
    sp(g, "Dihedral", "XSec_1", dihedral)
    ws = vsp.GetXSecSurf(g, 0)
    set_xs(xs(ws, 0), ThickChord=tc_root)
    set_xs(xs(ws, 1), ThickChord=tc_tip)
    set_xs(xs(ws, 1), SectTess_U=14)
    sp(g, "Tess_W", "Shape", 41)
    sp(g, "LECluster", "WingGeom", 0.2)
    place(g, x, y, z)
    set_color(g, *color)
    tag(g, *sets)
    vsp.Update()
    return g


def build(folded=False):
    vsp.ClearVSPModel()
    vsp.SetSetName(SET_OML, "OML")
    vsp.SetSetName(SET_INT, "Internal")
    vsp.SetSetName(SET_GEAR, "Gear_Hook")
    L, Wf, Df = P["L_fus"], P["W_fus"], P["D_fus"]

    # ------------------------------------------------------------ fuselage OML (L, W, D from sizing)
    # Rev E: straight-line (faceted) body. Width, height and centerline are PIECEWISE LINEAR in x:
    # a straight wedge nose to the full section, a constant mid-body, and a straight-tapered aft body,
    # sampled densely so the skinning spline follows straight lines (no ogive / boat-tail curvature).
    # Section: keystone (canted side walls, sharp lower chine), small top-corner radius.
    def lin(x, pts):
        for (x0, v0), (x1, v1) in zip(pts[:-1], pts[1:]):
            if x <= x1:
                return v0 + (v1 - v0) * (x - x0) / (x1 - x0)
        return pts[-1][1]
    W_pts = [(0.0, 0.0), (P["nose_end_x"], Wf), (P["aft_start_x"], Wf), (L, P["nozzle_w"])]
    H_pts = [(0.0, 0.0), (P["nose_end_x"], Df), (P["aft_start_x"], Df), (L, P["nozzle_h"])]
    Z_pts = [(0.0, -0.35), (P["nose_end_x"], 0.1), (P["aft_start_x"], 0.1), (L, 0.4)]
    xs_list = sorted(set([0.0, 0.6, 1.5] + [round(v, 3) for v in list(range(3, int(P["nose_end_x"]), 2))]
                         + [P["nose_end_x"] - 0.4, P["nose_end_x"], P["nose_end_x"] + 0.4,
                            P["aft_start_x"] - 0.4, P["aft_start_x"], P["aft_start_x"] + 0.4]
                         + [round(v, 3) for v in list(range(int(P["aft_start_x"]) + 2, int(L), 2))] + [L]))
    st = []
    for x in xs_list:
        if P["nose_end_x"] < x < P["aft_start_x"] and x not in (P["nose_end_x"] + 0.4, P["aft_start_x"] - 0.4):
            continue
        st.append((x, lin(x, W_pts), lin(x, H_pts), lin(x, Z_pts), 0.40))
    fus, s = fuselage_with("Fuselage", L, len(st))
    for i, (x, w, h, z, ks) in enumerate(st):
        vsp.ChangeXSecShape(s, i, vsp.XS_POINT if i == 0 else vsp.XS_ROUNDED_RECTANGLE)
        xi = xs(s, i)
        set_xs(xi, XLocPercent=x / L, ZLocPercent=z / L)
        if i > 0:
            # keystone widens the bottom edge to w*2*(1-ks); scale so the chine (max) width equals w
            r_top = min(0.08 * w, 0.20 * h)
            set_xs(xi, RoundedRect_Width=w / (2 * (1 - ks)), RoundedRect_Height=h, RoundRect_Keystone=ks,
                   RoundedRect_RadiusSymmetryType=vsp.SYM_RL,
                   RoundRectXSec_Radius=r_top, RoundRectXSec_RadiusTL=r_top,
                   RoundRectXSec_RadiusBR=0.04, RoundRectXSec_RadiusBL=0.04)
            set_xs(xi, SectTess_U=3)
        if i == len(st) - 1:
            straight_skin(xi)
    sp(fus, "Tess_W", "Shape", 41)
    sp(fus, "CapUMaxOption", "EndCap", vsp.FLAT_END_CAP)   # nozzle exit face
    set_color(fus, 170, 175, 185)
    tag(fus, SET_OML)

    # ------------------------------------------------------------ wing: inner + folding outer panel
    semi = b_w / 2
    c_fold = cr_w - (cr_w - ct_w) * P["fold_y"] / semi
    sweep = SZ["sweep_c4"]
    tc_fold = P["tc_root"] + (P["tc_tip"] - P["tc_root"]) * P["fold_y"] / semi
    w_in = lifting_surface("Wing_Inner", P["wing_x"], 0.0, P["wing_z"], P["fold_y"], cr_w, c_fold,
                           sweep, 0.25, 0.0, P["tc_root"], tc_fold)
    w_out = lifting_surface("Wing_Outer_Fold", P["wing_x"] + P["fold_y"] * tanLE_w, P["fold_y"], P["wing_z"],
                            semi - P["fold_y"], c_fold, ct_w, sweep, 0.25, 0.0, tc_fold, P["tc_tip"],
                            color=(150, 155, 168))
    if folded:
        sp(w_out, "X_Rel_Rotation", "XForm", 90.0)    # hinge along x at the fold station

    # ------------------------------------------------------------ PLANFORM ALIGNMENT (rev E)
    # Every leading edge is parallel in plan view to the wing LE (and every trailing edge to the wing TE),
    # so edge returns stack into the same few azimuths instead of spreading around the aircraft.
    # For horizontal-plane radar the edge 'flash' azimuth depends only on the edge's PLAN-VIEW angle,
    # so canted surfaces are aligned by their projected angle: tan(in-plane) = tan(plan) * cos(dihedral).
    tanTE_w = tanLE_w - (4 / SZ["AR"]) * (1 - SZ["taper"]) / (1 + SZ["taper"])
    LE_deg, TE_deg = math.degrees(math.atan(tanLE_w)), math.degrees(math.atan(tanTE_w))
    x_wing_ac = P["wing_x"] + ymac_w * tanLE_w + 0.25 * mac_w

    # horizontal tail (all-moving), Lt = 18 ft: area/AR from sizing; taper chosen so LE and TE both align
    b_ht = math.sqrt(AR_ht * S_ht)
    tap_ht_al = (1 - (tanLE_w - tanTE_w) * AR_ht / 4) / (1 + (tanLE_w - tanTE_w) * AR_ht / 4)
    cr_ht = 2 * S_ht / (b_ht * (1 + tap_ht_al)); ct_ht = cr_ht * tap_ht_al
    mac_ht = 2 / 3 * cr_ht * (1 + tap_ht_al + tap_ht_al ** 2) / (1 + tap_ht_al)
    ymac_ht = b_ht / 6 * (1 + 2 * tap_ht_al) / (1 + tap_ht_al)
    x_ht_root = x_wing_ac + SZ["Lt"] - 0.25 * mac_ht - ymac_ht * tanLE_w
    ht = lifting_surface("Horizontal_Tail", x_ht_root, 0.0, P["ht_z"], b_ht / 2, cr_ht, ct_ht,
                         LE_deg, 0.0, 0.0, 0.05, 0.04)

    # twin canted vertical tails: area/AR from sizing; in-plane LE/TE sweeps give aligned plan-view edges
    gam = math.radians(90.0 - P["vt_cant"])
    tanLE_v, tanTE_v = tanLE_w * math.cos(gam), tanTE_w * math.cos(gam)
    h_vt = math.sqrt(AR_vt * S_vt)
    cr_vt = (2 * S_vt / h_vt + h_vt * (tanLE_v - tanTE_v)) / 2
    ct_vt = 2 * S_vt / h_vt - cr_vt
    tap_vt_al = ct_vt / cr_vt
    mac_vt = 2 / 3 * cr_vt * (1 + tap_vt_al + tap_vt_al ** 2) / (1 + tap_vt_al)
    ymac_vt = h_vt / 3 * (1 + 2 * tap_vt_al) / (1 + tap_vt_al)
    x_vt_root = min(x_wing_ac + SZ["Lt"] - 0.25 * mac_vt - ymac_vt * tanLE_v, L - cr_vt + 0.2)
    vt = lifting_surface("Vertical_Tails", x_vt_root, P["vt_y"], P["vt_z"], h_vt, cr_vt, ct_vt,
                         math.degrees(math.atan(tanLE_v)), 0.0, 90.0 - P["vt_cant"], 0.05, 0.04)

    # ------------------------------------------------------------ chine inlets (caret-style fairing)
    inl, s = fuselage_with("Chine_Inlet", 14.0, 5)
    k = P["inlet_k"]
    for i, (fx, w, h, dy, dz) in enumerate([(0.0, 2.0 * k, 2.6 * k, 0.0, 0.0),
                                            (0.15, 1.95 * k, 2.5 * k, -0.1, 0.1),
                                            (0.40, 1.7 * k, 2.1 * k, -0.45, 0.35),
                                            (0.70, 1.1 * k, 1.4 * k, -1.0, 0.65),
                                            (1.0, 0.3, 0.4, -1.6, 0.9)]):
        vsp.ChangeXSecShape(s, i, vsp.XS_ROUNDED_RECTANGLE)
        xi = xs(s, i)
        set_xs(xi, XLocPercent=fx, YLocPercent=dy / 14.0, ZLocPercent=dz / 14.0, RoundedRect_Width=w,
               RoundedRect_Height=h, RoundRect_Keystone=0.6, RoundRectXSec_Radius=0.12 * w, SectTess_U=6)
    sp(inl, "Tess_W", "Shape", 25)
    set_xs(xs(s, 0), ZRotate=-(math.degrees(math.atan(tanLE_w)) + P["inlet_lip_trim_deg"]))  # lip parallel to wing LE (trim offsets skinning)
    sp(inl, "CapUMinOption", "EndCap", vsp.NO_END_CAP)
    place(inl, P["inlet_x"], P["inlet_y"], P["inlet_z"])
    sp(inl, "Sym_Planar_Flag", "Sym", vsp.SYM_XZ)
    set_color(inl, 120, 110, 200)
    tag(inl, SET_OML)

    # ------------------------------------------------------------ internal arrangement
    sn = P["sensor_nose"]; box("Sensor_Nose", sn["x"], sn["L"], sn["w"], sn["h"], z=sn["z"], color=(216, 90, 48))
    a = P["avionics"]; box("Avionics_Bay", a["x"], a["L"], a["w"], a["h"], z=a["z"], color=(216, 90, 48))
    bb = P["bay"]; box("Weapons_Bay", bb["x"], bb["L"], bb["w"], bb["h"], z=bb["z"], color=(216, 90, 48))
    for name, t, sym in P["tanks"]:
        box(name, t["x"], t["L"], t["w"], t["h"], y=t["y"], z=t["z"], color=(29, 158, 117), sym=sym)
    for name, wl, sym in (("Main_Gear_Well", P["main_well"], True), ("Nose_Gear_Well", P["nose_well"], False)):
        box(name, wl["x"], wl["L"], wl["w"], wl["h"], y=wl["y"], z=wl["z"], color=(120, 120, 120), sym=sym)
    e = P["engine"]; cylinder("Engine_F414", P["engine_x"], e["L"], e["d"], z=e["z"], color=(83, 74, 183))

    dL = SZ["L_duct"]
    duct, s = fuselage_with("S_Duct", dL, 4)
    d0, d1 = P["duct_d_throat"], P["duct_d_face"]       # monotonic subsonic diffuser, face/throat = 1.15
    for i, (dx, dy, dz, dia) in enumerate([(0.0, 0.0, 0.0, d0), (0.40 * dL, 0.0, 1.2, d0 + 0.3 * (d1 - d0)),
                                           (0.78 * dL, -1.4, 1.5, d0 + 0.75 * (d1 - d0)),
                                           (dL, -P["inlet_y"], 1.1, d1)]):
        vsp.ChangeXSecShape(s, i, vsp.XS_CIRCLE)
        set_xs(xs(s, i), XLocPercent=dx / dL, YLocPercent=dy / dL, ZLocPercent=dz / dL, Circle_Diameter=dia)
        straight_skin(xs(s, i))
    sp(duct, "CapUMinOption", "EndCap", vsp.NO_END_CAP)
    sp(duct, "CapUMaxOption", "EndCap", vsp.NO_END_CAP)
    place(duct, P["inlet_x"], P["inlet_y"], P["inlet_z"])
    sp(duct, "Sym_Planar_Flag", "Sym", vsp.SYM_XZ)
    set_color(duct, 127, 119, 221)
    tag(duct, SET_INT)

    # auxiliary blow-in doors (catapult / wave-off): flush panels on the canted side wall above each duct,
    # spring-loaded open at low speed / high airflow, closed and sealed in flight (edges to be sawtoothed).
    ad = P["aux_door"]
    side_cant = math.degrees(math.atan((Wf / 2 - Wf / 2 * 0.40 / 0.60) / Df))   # keystone side-wall lean
    hw_bot, hw_top = Wf / 2, Wf / 2 * 0.40 / 0.60
    z_bot, z_top = 0.1 - Df / 2, 0.1 + Df / 2
    y_wall = hw_bot + (hw_top - hw_bot) * (ad["z"] - z_bot) / (z_top - z_bot) - 0.03
    for j in range(ad["n_per_side"]):
        dg = box(f"Aux_Inlet_Door_{j + 1}", ad["x"] + j * (ad["L"] + ad["gap"]), ad["L"], 0.06, ad["h"],
                 y=y_wall, z=ad["z"], r=0.02, sets=(SET_OML,), color=(230, 180, 40), sym=True)
        sp(dg, "X_Rel_Rotation", "XForm", side_cant)

    # ------------------------------------------------------------ landing gear (Gear geom: tires + ground plane + CG)
    gear = vsp.AddGeom("GEAR")
    vsp.SetGeomName(gear, "Landing_Gear")
    sp(gear, "m_ModelLenUnits", "Gear", vsp.LEN_FT)
    sp(gear, "AutoPlaneFlag", "GroundPlane", 0.0)
    sp(gear, "PlaneSize", "GroundPlane", 30.0)
    place(gear, z=P["ground_z"])
    cgx, cgy, cgz = P["cg"]
    sp(gear, "CGLocalFlag", "GroundPlane", 0.0)
    for k in ("Min", "Max", "Nominal"):
        sp(gear, f"XCG{k}Global", "GroundPlane", cgx)
        sp(gear, f"YCG{k}Global", "GroundPlane", cgy)
        sp(gear, f"ZCG{k}Global", "GroundPlane", cgz)
    for (xc, yc, tire, n_across, sym) in [(P["main_gear_x"], P["main_gear_y"], P["main_tire"], 1, 1.0),
                                          (P["nose_gear_x"], 0.0, P["nose_tire"], 2, 0.0)]:
        bg = vsp.CreateAndAddBogie(gear)
        vsp.SetParmVal(bg, "Symmetrical", "Bogie", sym)
        vsp.SetParmVal(bg, "NumAcross", "Bogie", n_across)
        vsp.SetParmVal(bg, "XContactPt", "Bogie", xc)
        vsp.SetParmVal(bg, "YContactPt", "Bogie", yc)
        vsp.SetParmVal(bg, "ZAboveGround", "Bogie", 0.0)
        vsp.SetParmVal(bg, "DiameterIn", "Tire", tire[0])
        vsp.SetParmVal(bg, "WidthIn", "Tire", tire[1])
    set_color(gear, 40, 40, 40)
    tag(gear, SET_GEAR)

    # main gear: canted oleo from wing-root trunnion to axle (F/A-18-style splayed carrier gear)
    tx, ty, tz = P["main_trunnion"]
    mg = cylinder("Main_Oleo", P["main_gear_x"], P["main_strut_len"], 0.55, y=P["main_gear_y"],
                  z=P["main_axle_z"], ry=-90.0, sets=(SET_GEAR,), color=(90, 90, 90), sym=True)
    sp(mg, "X_Rel_Rotation", "XForm", P["main_cant_deg"])
    cylinder("Main_Axle", P["main_gear_x"] - 0.15, 0.3, 0.9, y=P["main_gear_y"] - 0.45, z=P["main_axle_z"],
             sets=(SET_GEAR,), color=(70, 70, 70), sym=True)
    # nose gear: long dual-wheel oleo with launch bar and holdback fitting
    cylinder("Nose_Oleo", P["nose_gear_x"], P["nose_strut_static"], 0.5, z=P["nose_axle_z"],
             ry=-90.0, sets=(SET_GEAR,), color=(90, 90, 90))
    cylinder("Launch_Bar", P["nose_gear_x"], 3.0, 0.25, z=P["nose_axle_z"] + 0.4, ry=160.0,
             sets=(SET_GEAR,), color=(90, 90, 90))
    cylinder("Holdback_Fitting", P["nose_gear_x"] + 0.4, 1.4, 0.2, z=P["nose_axle_z"] + 0.9, ry=30.0,
             sets=(SET_GEAR,), color=(90, 90, 90))
    hx, hz = P["hook_pivot"]
    cylinder("Arresting_Hook", hx, P["hook_len"], 0.35, z=hz, ry=P["hook_deg"],
             sets=(SET_GEAR,), color=(230, 180, 40))

    vsp.Update()
    return dict(S_w=S_w, b_w=b_w, cr_w=cr_w, ct_w=ct_w, c_fold=c_fold, mac_w=mac_w, x_wing_ac=x_wing_ac,
                S_ht=S_ht, b_ht=b_ht, cr_ht=cr_ht, x_ht_root=x_ht_root, S_vt_each=S_vt, h_vt=h_vt,
                cr_vt=cr_vt, x_vt_root=x_vt_root, inlet_x=P["inlet_x"], inlet_w=P["inlet_w"], inlet_h=P["inlet_h"],
                inlet_y=P["inlet_y"], duct_d_throat=P["duct_d_throat"], duct_d_face=P["duct_d_face"],
                aux_door_area_total=P["aux_door"]["L"] * P["aux_door"]["h"] * P["aux_door"]["n_per_side"] * 2,
                ground_z=P["ground_z"], main_cant=P["main_cant_deg"], main_strut_static=P["main_strut_len"],
                nose_strut_static=P["nose_strut_static"], nose_oleo_ext_in=P["nose_oleo_ext_in"],
                hook_deg=P["hook_deg"], LE_align_deg=LE_deg, TE_align_deg=TE_deg, tap_ht=tap_ht_al,
                cr_ht_al=cr_ht, vt_inplane_LE=math.degrees(math.atan(tanLE_v)), cr_vt_al=cr_vt, ct_vt_al=ct_vt)


if __name__ == "__main__":
    import sys
    out = sys.argv[1] if len(sys.argv) > 1 else "."
    print(f"Sizing source: {SOURCE}")
    print(f"Sizing closure: W_TO {W_TO:.0f} lb, OEW {OEW:.0f} lb, fuel {W_energy:.0f} lb")
    for folded, fname in [(False, "ConceptA_unfolded.vsp3"), (True, "ConceptA_folded.vsp3")]:
        info = build(folded)
        vsp.WriteVSPFile(f"{out}/{fname}", vsp.SET_ALL)
    for k, v in info.items():
        print(f"  {k:12s} {v:8.2f}")
