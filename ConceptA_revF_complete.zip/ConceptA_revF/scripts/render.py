import sys, os, struct, tempfile
import numpy as np
import openvsp_config
openvsp_config.LOAD_GRAPHICS = False
import openvsp as vsp
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

COLORS = {
    "Fuselage": "#b8bcc6", "Wing_Inner": "#b8bcc6", "Wing_Outer_Fold": "#9aa0ad", "Horizontal_Tail": "#b8bcc6", "Vertical_Tails": "#b8bcc6", "Fuel_Aft_Saddle": "#1D9E75",
    "Chine_Inlet": "#7F77DD", "S_Duct": "#7F77DD", "Engine_F414": "#534AB7",
    "Avionics_Bay_1000lb": "#D85A30", "Weapons_Bay": "#D85A30", "Fuel_Dorsal": "#1D9E75",
    "Landing_Gear": "#2C2C2A", "Main_Strut": "#5F5E5A", "Nose_Strut": "#5F5E5A",
    "Launch_Bar": "#5F5E5A", "Arresting_Hook": "#BA7517",
}
PREFIX_COLORS = [("Aux_Inlet_Door", "#EF9F27"), ("Fuel_", "#1D9E75"), ("Sensor_", "#D85A30"), ("Avionics", "#D85A30"),
                 ("_Well", "#888780"), ("Oleo", "#5F5E5A"), ("Axle", "#444441"), ("Holdback", "#5F5E5A")]


def color_of(name):
    if name in COLORS:
        return COLORS[name]
    for k, c in PREFIX_COLORS:
        if k in name:
            return c
    return "#999999"


def is_internal(name):
    return name in INTERNAL or name.startswith("Fuel_") or name.endswith("_Well") or name in ("Sensor_Nose", "Avionics_Bay")


INTERNAL = {"Fuel_Aft_Saddle", "S_Duct", "Engine_F414", "Avionics_Bay_1000lb", "Weapons_Bay", "Fuel_Dorsal"}


def read_stl(path):
    tris = []
    with open(path, "rb") as f:
        data = f.read()
    if data[:5] == b"solid" and b"facet" in data[:400]:
        v = []
        for line in data.decode(errors="ignore").splitlines():
            line = line.strip()
            if line.startswith("vertex"):
                v.append([float(t) for t in line.split()[1:4]])
        tris = np.array(v).reshape(-1, 3, 3)
    else:
        n = struct.unpack("<I", data[80:84])[0]
        arr = np.frombuffer(data[84:84 + n * 50], dtype=np.dtype([("n", "<3f4"), ("v", "<9f4"), ("a", "<u2")]))
        tris = arr["v"].reshape(-1, 3, 3).astype(float)
    return tris


def meshes(vsp3):
    vsp.ClearVSPModel()
    vsp.ReadVSPFile(vsp3)
    vsp.Update()
    out = {}
    tmp = tempfile.mkdtemp()
    TMPSET = 15
    for g in vsp.FindGeoms():
        name = vsp.GetGeomName(g)
        if name == "Landing_Gear":
            vsp.SetParmVal(g, "ShowNominalGroundPlane", "GroundPlane", 0.0)
            vsp.Update()
        for g2 in vsp.FindGeoms():
            vsp.SetSetFlag(g2, TMPSET, g2 == g)
        p = os.path.join(tmp, name + ".stl")
        vsp.ExportFile(p, TMPSET, vsp.EXPORT_STL)
        if os.path.exists(p) and os.path.getsize(p) > 200:
            out[name] = read_stl(p)
    return out


def rot(elev, azim):
    a, e = np.radians(azim), np.radians(elev)
    Rz = np.array([[np.cos(a), -np.sin(a), 0], [np.sin(a), np.cos(a), 0], [0, 0, 1]])
    Rx = np.array([[1, 0, 0], [0, np.cos(e), -np.sin(e)], [0, np.sin(e), np.cos(e)]])
    return Rx @ Rz


VIEWS = {  # rows of R map world (x aft, y right, z up) -> screen (u right, v up, w toward viewer)
    "Top": np.array([[1, 0, 0], [0, -1, 0], [0, 0, 1.0]]),
    "Side (left)": np.array([[1, 0, 0], [0, 0, 1], [0, -1.0, 0]]),
    "Front": np.array([[0, -1, 0], [0, 0, 1], [-1.0, 0, 0]]),
}


CULL = ("Chine_Inlet", "Wing_Inner", "Horizontal_Tail", "Vertical_Tails")


def cull_buried(ms):
    """Drop surface triangles of OML parts that are buried inside the fuselage (renderer only)."""
    import trimesh
    v = ms["Fuselage"].reshape(-1, 3)
    fus = trimesh.Trimesh(vertices=v, faces=np.arange(len(v)).reshape(-1, 3))
    fus.merge_vertices()
    out = dict(ms)
    for k in CULL:
        if k in ms:
            c = ms[k].mean(1)
            out[k] = ms[k][~fus.contains(c)]
    return out


def draw(ax, ms, R, ghost=False, title=""):
    from matplotlib.collections import PolyCollection
    from matplotlib.colors import to_rgb
    polys, cols, depth = [], [], []
    light = np.array([0.3, 0.5, 0.8]); light /= np.linalg.norm(light)
    for name, t in ms.items():
        internal = is_internal(name)
        if internal and not ghost:
            continue
        T = t @ R.T
        n = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0])
        nn = np.linalg.norm(n, axis=1); ok = nn > 1e-12
        T = T[ok]
        try:   # smooth shading: average vertex normals over each face
            import trimesh
            m = trimesh.Trimesh(vertices=T.reshape(-1, 3), faces=np.arange(len(T) * 3).reshape(-1, 3), process=False)
            m.merge_vertices(merge_tex=True, merge_norm=True)
            vn = m.vertex_normals[m.faces].mean(1)
            n = vn / np.maximum(np.linalg.norm(vn, axis=1, keepdims=True), 1e-9)
        except Exception:
            n = n[ok] / nn[ok, None]
        shade = 0.50 + 0.50 * np.abs(n @ light)
        base = np.array(to_rgb(color_of(name)))
        a = 1.0 if (internal or not ghost) else 0.10
        c = np.clip(base[None, :] * shade[:, None], 0, 1)
        polys.extend(T[:, :, :2]); depth.extend(T[:, :, 2].mean(1) + (1000 if (ghost and internal) else 0))
        cols.extend(np.hstack([c, np.full((len(c), 1), a)]))
    order = np.argsort(depth)
    pc = PolyCollection([polys[i] for i in order], facecolors=[cols[i] for i in order], edgecolors="none")
    ax.add_collection(pc)
    P = np.vstack(polys)
    ax.set_xlim(P[:, 0].min() - 1, P[:, 0].max() + 1); ax.set_ylim(P[:, 1].min() - 1, P[:, 1].max() + 1)
    ax.set_aspect("equal"); ax.set_axis_off(); ax.set_title(title, fontsize=11)


def sheet(vsp3, png, ghost, title):
    ms = cull_buried(meshes(vsp3))
    fig = plt.figure(figsize=(15, 10), dpi=120)
    gs = fig.add_gridspec(2, 2, height_ratios=[1.15, 1])
    specs = [(gs[0, 0], rot(-28, 0) @ np.diag([1, 1, 1.0]) , "Isometric"), (gs[0, 1], VIEWS["Top"], "Top"),
             (gs[1, 0], VIEWS["Side (left)"], "Side (left)"), (gs[1, 1], VIEWS["Front"], "Front")]
    for spec, R, t in specs:
        if t == "Isometric":
            R = rot(30, 0) @ rot(0, 225)[[0, 1, 2]]
            R = np.array([[0.70, -0.70, 0.0], [0.33, 0.33, 0.88], [-0.62, -0.62, 0.48]])
            R = R / np.linalg.norm(R, axis=1, keepdims=True)
        ax = fig.add_subplot(spec)
        draw(ax, ms, R, ghost, t)
    fig.suptitle(title, fontsize=13)
    plt.tight_layout()
    fig.savefig(png)
    return ms


if __name__ == "__main__":
    ms = sheet(sys.argv[1], sys.argv[2], ghost=(len(sys.argv) > 3 and sys.argv[3] == "ghost"), title=sys.argv[4] if len(sys.argv) > 4 else "")
    for k, t in ms.items():
        P = t.reshape(-1, 3)
        print(f"{k:22s} n={len(t):6d}  x[{P[:,0].min():6.1f},{P[:,0].max():6.1f}] "
              f"y[{P[:,1].min():6.1f},{P[:,1].max():6.1f}] z[{P[:,2].min():6.1f},{P[:,2].max():6.1f}]")
