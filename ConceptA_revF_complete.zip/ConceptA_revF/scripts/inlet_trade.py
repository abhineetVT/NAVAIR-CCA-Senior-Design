"""Inlet / engine airflow matching trade study - Concept A rev E (twin chine inlets, single F414-GE-400).

Question: do the inlets deliver enough air, at acceptable quality, for the F414 across the mission?

Method (Raymer Ch.10 / Mattingly Ch.10 conceptual inlet sizing):
  * Engine demand: corrected airflow W_c [lb/s]. F414-GE-400 = 170 lb/s at max power, SL static (GE datasheet).
    Max corrected flow held to the throttle ratio theta_break, then W_c ~ sqrt(theta_break/theta_t) above it
    (temperature-limited fan speed). Part-power corrected flow given per condition (assumption).
  * Physical flow m = W_c * delta_face / sqrt(theta_t),  delta_face = delta_t0 * recovery.
  * Free-stream capture tube A0 = m / (rho0 V0);  mass-flow ratio MFR = A0 / A_capture.
      MFR < 1: inlet spills air (external diffusion, spillage drag).  MFR > 1: inlet sucks air round the lips.
  * Throat and engine-face Mach from the isentropic mass-flow function.
  * Total-pressure recovery = lip x duct.  Thrust loss %dT = C_ram (1 - recovery) x 100, C_ram = 1.35.
All loss coefficients are conceptual-design assumptions, flagged below, to be replaced by CFD/test data.
"""
import math
import numpy as np

G, R = 1.4, 1716.49            # ft-lbf/(slug R)
P_SL, T_SL, RHO_SL = 2116.22, 518.67, 0.0023769
LBM_PER_SLUG = 32.174

# ------------------------------------------------------------------ inputs
WC_MAX = 170.0                 # lb/s, F414-GE-400 airflow (GE datasheet)
D_FACE_IN = 31.0               # in, F414 inlet (fan face) diameter (GE datasheet)
A_FACE = math.pi / 4 * (D_FACE_IN / 12) ** 2
A_CAP0 = 2 * 3.88              # ft^2, frontal capture area, both inlets (measured from rev E mesh)
A_THR0 = 2 * math.pi / 4 * 1.9 ** 2   # ft^2, duct entry/throat, both ducts (rev E model)
THETA_BREAK = 1.07             # throttle ratio typical of fighter engines (Mattingly) [assumption]
K_DUCT = 0.15                  # S-duct total-pressure loss coeff. on throat dynamic pressure (well-designed, moderate offset ~0.10-0.20) [assumption]
K_LIP_SHARP, K_LIP_BLUNT = 0.08, 0.02   # suction-flow lip loss (sharp stealth lip vs. blunt lip/aux doors) [assumption]
C_RAM = 1.35                   # Raymer ram-recovery thrust correction factor (subsonic)

# name, alt ft, Mach, corrected-flow fraction of max, note
CONDITIONS = [
    ("Catapult hold / launch (max AB, static)", 0, 0.0, 1.00),
    ("Catapult end of stroke (max AB, ~150 kt)", 0, 0.23, 1.00),
    ("Wave-off / bolter (max AB, 145 kt)", 0, 0.22, 1.00),
    ("Carrier approach (~70% Wc, 145 kt)", 0, 0.22, 0.70),
    ("Climb, SL M0.3 (max dry)", 0, 0.30, 1.00),
    ("Strike dash, SL M0.8 (max dry)", 0, 0.80, 1.00),
    ("Cruise, 30 kft M0.7 (~85% Wc)", 30000, 0.70, 0.85),
    ("Dash, 30 kft M0.8 (max dry)", 30000, 0.80, 1.00),
    ("Dash, 30 kft M0.85 (max dry)", 30000, 0.85, 1.00),
    ("Combat, 10 kft M0.6 (max AB)", 10000, 0.60, 1.00),
    ("Loiter, 10 kft M0.45 (~70% Wc)", 10000, 0.45, 0.70),
]


def isa(h):
    if h <= 36089:
        T = T_SL - 0.00356616 * h
        p = P_SL * (T / T_SL) ** 5.2559
    else:
        T = 389.97
        p = 472.68 * math.exp(-(h - 36089) / 20806)
    return T, p, p / (R * T)


def mff(M):
    """corrected mass flow per area [lbm/s/ft^2] at SL-standard total conditions, as a function of Mach."""
    return (P_SL * math.sqrt(G / (R * T_SL)) * M * (1 + 0.2 * M * M) ** -3.0) * LBM_PER_SLUG


MFF_CHOKE = mff(1.0)


def mach_from_wca(wc_per_area):
    if wc_per_area >= MFF_CHOKE:
        return float("nan")      # choked
    lo, hi = 0.0, 1.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if mff(mid) < wc_per_area:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def evaluate(cap_scale=1.0, thr_scale=None, k_lip=K_LIP_SHARP, verbose=False):
    thr_scale = cap_scale if thr_scale is None else thr_scale
    A_cap, A_thr = A_CAP0 * cap_scale, A_THR0 * thr_scale
    rows = []
    for name, h, M, frac in CONDITIONS:
        T, p, rho = isa(h)
        a = math.sqrt(G * R * T)
        V = M * a
        Tt, pt = T * (1 + 0.2 * M * M), p * (1 + 0.2 * M * M) ** 3.5
        theta, delta = Tt / T_SL, pt / P_SL
        wc = WC_MAX * frac * (1.0 if theta <= THETA_BREAK else math.sqrt(THETA_BREAK / theta))
        # iterate recovery (it depends on throat Mach and MFR)
        rec = 0.97
        for _ in range(200):
            m = wc * delta * rec / math.sqrt(theta)                 # lbm/s physical
            A0 = m / (rho * LBM_PER_SLUG * V) if V > 1 else float("inf")
            mfr = A0 / A_cap
            eta_lip = rec_lip_only(mfr, k_lip)
            # corrected flow at the throat = engine corrected flow x duct recovery (duct losses are downstream)
            Mt = mach_from_wca(wc * (rec / eta_lip) / A_thr)
            q_ratio = (G / 2) * Mt * Mt * (1 + 0.2 * Mt * Mt) ** -3.5 if Mt == Mt else 0.7
            rec_new = eta_lip * (1 - K_DUCT * q_ratio)
            if abs(rec_new - rec) < 1e-7:
                break
            rec = 0.5 * rec + 0.5 * rec_new
        Mf = mach_from_wca(wc / A_FACE)
        rows.append(dict(name=name, alt=h, M=M, wc=wc, m=m, A0=A0, mfr=mfr, Mt=Mt, Mf=Mf, rec=rec,
                         dT=C_RAM * (1 - rec) * 100))
    return rows, A_cap, A_thr


def rec_lip_only(mfr, k_lip):
    """Lip/entry recovery: ~1 when spilling (MFR<=1); suction losses grow as MFR>1 (sharp lips worst)."""
    if mfr <= 1.0:
        return 1.0
    if math.isinf(mfr):
        return 1.0 - k_lip
    return 1.0 - k_lip * (1.0 - 1.0 / mfr) ** 2


if __name__ == "__main__":
    rows, A_cap, A_thr = evaluate()
    print(f"F414 face {A_FACE:.2f} ft^2 | capture {A_cap:.2f} ft^2 | throat {A_thr:.2f} ft^2 | "
          f"capture/face {A_cap/A_FACE:.2f} | face/throat (diffusion) {A_FACE/A_thr:.2f}")
    print(f"{'condition':44s} {'Wc':>5s} {'m lb/s':>7s} {'A0 ft2':>7s} {'MFR':>5s} {'M_thr':>6s} {'M_face':>6s} {'recov':>6s} {'dT%':>5s}")
    for r in rows:
        mfr = "  inf" if math.isinf(r["mfr"]) else f"{r['mfr']:5.2f}"
        A0 = "    inf" if math.isinf(r["A0"]) else f"{r['A0']:7.2f}"
        print(f"{r['name']:44s} {r['wc']:5.0f} {r['m']:7.1f} {A0} {mfr} {r['Mt']:6.2f} {r['Mf']:6.2f} {r['rec']:6.3f} {r['dT']:5.1f}")
    rows_b, _, _ = evaluate(k_lip=K_LIP_BLUNT)
    print("\nWith blunted lips / auxiliary blow-in doors (low-speed suction cases only):")
    for r in rows_b[:4]:
        print(f"  {r['name']:44s} recovery {r['rec']:.3f}, thrust loss {r['dT']:.1f}%")


# ------------------------------------------------------------------ capture-area trade sweep
def sweep(contraction=1.25, caps=None):
    caps = np.linspace(3.5, 9.0, 56) if caps is None else caps
    out = []
    for Ac in caps:
        At = Ac / contraction
        rows, _, _ = evaluate(cap_scale=Ac / A_CAP0, thr_scale=At / A_THR0)
        rows_b, _, _ = evaluate(cap_scale=Ac / A_CAP0, thr_scale=At / A_THR0, k_lip=K_LIP_BLUNT)
        d = {r["name"]: r for r in rows}
        db = {r["name"]: r for r in rows_b}
        mt_max = max(r["Mt"] if r["Mt"] == r["Mt"] else 1.0 for r in rows)
        out.append(dict(Ac=Ac, At=At, mt_max=mt_max, diff=A_FACE / At,
                        mfr_cruise=d["Cruise, 30 kft M0.7 (~85% Wc)"]["mfr"],
                        mfr_dash=d["Dash, 30 kft M0.85 (max dry)"]["mfr"],
                        mfr_sl=d["Strike dash, SL M0.8 (max dry)"]["mfr"],
                        mfr_combat=d["Combat, 10 kft M0.6 (max AB)"]["mfr"],
                        mfr_wo=d["Wave-off / bolter (max AB, 145 kt)"]["mfr"],
                        dT_static=d["Catapult hold / launch (max AB, static)"]["dT"],
                        dT_static_b=db["Catapult hold / launch (max AB, static)"]["dT"],
                        dT_wo=d["Wave-off / bolter (max AB, 145 kt)"]["dT"],
                        dT_wo_b=db["Wave-off / bolter (max AB, 145 kt)"]["dT"],
                        dT_cruise=d["Cruise, 30 kft M0.7 (~85% Wc)"]["dT"],
                        dT_combat=d["Combat, 10 kft M0.6 (max AB)"]["dT"]))
    return out


def recommend(res, mfr_target=(0.60, 0.75), mt_limit=0.65, diff_rng=(1.05, 1.40)):
    ok = [r for r in res if mfr_target[0] <= r["mfr_cruise"] <= mfr_target[1]
          and r["mt_max"] <= mt_limit and diff_rng[0] <= r["diff"] <= diff_rng[1]
          and r["mfr_combat"] <= 1.0]
    return ok
