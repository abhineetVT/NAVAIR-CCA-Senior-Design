"""Carrier landing-gear sizing for Concept A (Raymer Ch. 11 methods + MIL-A-8863C sink rates).

Compares a Navy (arrested-landing) gear with a land-based (USAF-style) gear on the same airframe,
so the size difference is explicit and traceable.
"""
import math
from sizing_port import W_TO, W_energy

g = 32.174
# ---------------------------------------------------------------- inputs
W_land = W_TO - 0.75 * W_energy       # RFP arrestment weight basis (as in sizing model)
V_sink_navy = 22.0                    # ft/s design limit sink speed, carrier (20-23 ft/s typical)
V_sink_land = 10.0                    # ft/s land-based design sink speed (FAR / USAF-type)
N_gear = 5.0                          # gear load factor (matches N_gear_limit in sizing model)
eta_oleo, eta_tire = 0.80, 0.47       # Raymer: oleo-pneumatic and tire efficiencies
x_cg, x_main, x_nose = 24.7, 27.4, 10.0   # ft (CG estimate; gear stations in the model)
h_cg = 6.2                            # ft CG height above deck at static (from model)


def stroke_in(V, tire_defl_in):
    """Raymer eq. 11.4: required oleo stroke, plus 1 in margin."""
    S_ft = V ** 2 / (2 * g * eta_oleo * N_gear) - (eta_tire / eta_oleo) * tire_defl_in / 12
    return S_ft * 12 + 1.0


def tire(load_lb):
    """Raymer Table 11.1, fighter/jet-trainer statistics (diameter, width in inches)."""
    return 1.63 * load_lb ** 0.315, 0.1043 * load_lb ** 0.480


# ---------------------------------------------------------------- loads
B = x_main - x_nose
main_static_each = W_TO * (x_cg - x_nose) / B / 2          # per main wheel (1 wheel per strut)
nose_static = W_TO * (x_main - x_cg) / B
nose_dyn = 10 * h_cg * W_TO / (g * B)                      # Raymer dynamic braking, 10 ft/s^2
nose_each = (nose_static + nose_dyn) / 2                   # dual nose wheels

D_main, W_main = tire(main_static_each)
D_nose, W_nose = tire(nose_each)
tire_defl_main = 0.30 * (D_main - 0.62 * D_main) / 1.0     # ~30% of sidewall height at max load

S_navy = stroke_in(V_sink_navy, tire_defl_main)
S_land = stroke_in(V_sink_land, tire_defl_main)
L_oleo_navy = 2.5 * S_navy                                 # Raymer: oleo length ~2.5x stroke
L_oleo_land = 2.5 * S_land
D_oleo = 1.3 * 0.04 * math.sqrt(main_static_each * N_gear / 1.0) / math.sqrt(N_gear) * math.sqrt(1.0)

E_navy = 0.5 * (W_land / g) * V_sink_navy ** 2
E_land = 0.5 * (W_land / g) * V_sink_land ** 2

RESULTS = dict(
    W_land=W_land, main_static_each=main_static_each, nose_static=nose_static, nose_dyn=nose_dyn,
    D_main=D_main, W_main=W_main, D_nose=D_nose, W_nose=W_nose,
    S_navy=S_navy, S_land=S_land, L_oleo_navy=L_oleo_navy, L_oleo_land=L_oleo_land,
    E_navy=E_navy, E_land=E_land,
)

# Chosen gear for the model (rounded to standard-ish sizes, conservative)
MAIN_TIRE = (32.0, 11.5)     # in: diameter, width  (statistical 31.9 x 9.7 in -> next size up)
NOSE_TIRE = (22.0, 6.6)      # in: dual, statistical ~21.5 in
MAIN_STROKE_IN = 22.0
NOSE_STROKE_IN = 18.0        # nose also absorbs nose-slap and catapult tension/release
MAIN_OLEO_EXT_IN = 2.5 * MAIN_STROKE_IN
NOSE_OLEO_EXT_IN = 2.5 * NOSE_STROKE_IN

if __name__ == "__main__":
    r = RESULTS
    print(f"Arrestment weight {r['W_land']:.0f} lb, gear load factor {N_gear}")
    print(f"Static load per main wheel {r['main_static_each']:.0f} lb; nose static {r['nose_static']:.0f} "
          f"+ braking {r['nose_dyn']:.0f} lb (dual wheels)")
    print(f"Main tire (Raymer stats) {r['D_main']:.1f} x {r['W_main']:.1f} in -> chosen {MAIN_TIRE[0]} x {MAIN_TIRE[1]}")
    print(f"Nose tire (Raymer stats) {r['D_nose']:.1f} x {r['W_nose']:.1f} in -> chosen dual {NOSE_TIRE[0]} x {NOSE_TIRE[1]}")
    print(f"{'':28s}{'Navy (22 ft/s)':>16s}{'Land (10 ft/s)':>16s}{'ratio':>8s}")
    print(f"{'Sink energy, ft-lb':28s}{r['E_navy']:16,.0f}{r['E_land']:16,.0f}{r['E_navy']/r['E_land']:8.1f}")
    print(f"{'Oleo stroke, in':28s}{r['S_navy']:16.1f}{r['S_land']:16.1f}{r['S_navy']/r['S_land']:8.1f}")
    print(f"{'Oleo extended length, in':28s}{r['L_oleo_navy']:16.1f}{r['L_oleo_land']:16.1f}")
