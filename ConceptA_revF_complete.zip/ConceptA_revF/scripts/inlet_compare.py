import numpy as np, matplotlib, trimesh, render
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
fig, axs = plt.subplots(1, 2, figsize=(14, 5.6), dpi=130)
for ax, (d, title) in zip(axs, (("revE", "Rev E: capture 7.76 ft² (MFR 0.44 at M0.9)"), (".", "Rev F: capture 5.70 ft² (MFR 0.60 at M0.9) + aux doors"))):
    ms = render.meshes(f"{d}/ConceptA_unfolded.vsp3")
    for k, col in (("Fuselage", (0.72, 0.74, 0.78, 1)), ("Chine_Inlet", (0.50, 0.47, 0.85, 1))):
        t = ms[k]; t = t[t[:, :, 0].max(1) < 14.5]
        ax.add_collection(PolyCollection(t[:, :, [1, 2]] * [-1, 1], facecolors=[col], edgecolors="none"))
    for k in ms:
        if k.startswith("Aux_Inlet_Door"):
            ax.add_collection(PolyCollection(ms[k][:, :, [1, 2]] * [-1, 1], facecolors=["#EF9F27"], edgecolors="none"))
    v = ms["Chine_Inlet"].reshape(-1, 3); m = trimesh.Trimesh(vertices=v, faces=np.arange(len(v)).reshape(-1, 3)); m.merge_vertices()
    u, c = np.unique(m.edges_sorted, axis=0, return_counts=True)
    for e in u[c == 1]:
        p = m.vertices[e]
        if p[:, 0].max() < 14.5: ax.plot(-p[:, 1], p[:, 2], color="#26215C", lw=1.6)
    ax.set_xlim(-5.2, 5.2); ax.set_ylim(-3.4, 3.4); ax.set_aspect("equal"); ax.grid(alpha=0.25)
    ax.set_title(title, loc="left", fontsize=11); ax.set_xlabel("y (ft)"); ax.set_ylabel("z (ft)")
fig.suptitle("Front view, forward fuselage (x < 14.5 ft): inlet mouth (dark outline), fairing (violet), aux blow-in doors (amber)", x=0.01, ha="left", fontsize=12)
fig.tight_layout(); fig.savefig("ConceptA_revE_vs_revF_inlets.png")
