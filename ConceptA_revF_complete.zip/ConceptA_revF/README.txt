Concept A rev F (Gobbleworks Team 11) - current model, 2026-11-17

vsp/      OpenVSP 3.56 models: flight (unfolded) and deck-stowage (wings folded).
          Sets: OML, Internal, Gear_Hook.
json/     sizing_point_conceptA.json - converged point from the team cca_sizing framework (counter-air
          sizing case: 25,966 lb TOGW, 245 ft^2 wing). conceptA_strike/counter.json - framework inputs
          with Concept A geometry (drop into cca_sizing/).
scripts/  build_concept_a.py regenerates both .vsp3 files (needs the OpenVSP Python API);
          checks.py = RFP limits, edge alignment, inlet capture, fuel, interference, gear;
          inlet_trade.py = inlet/F414 airflow matching. Scripts read sizing_point_conceptA.json in this folder.
reports/  checks_output.txt, ConceptA_revF_speed_check.txt, inlet_trade_results.txt
images/   renders, inlet comparison, inlet trade chart, planform-alignment diagram

Rev F key numbers: length 47.4 ft, span 31.3/17.8 ft (folded), folded height 12.4 ft; LE sweep 40.4 deg
(wing, inlet lips, tails), TE 14.1 deg; inlet capture 5.70 ft^2, ducts 1.70->1.83 ft to the 31-in F414 face,
aux blow-in doors 2.4 ft^2; fuel 115% of counter-air requirement; carrier gear 22 ft/s sink, turnover 48.3 deg.
