function plot_drag_polar(disc, result)
%PLOT_DRAG_POLAR  Drag polars of the converged aircraft at key flight conditions.
    g    = disc.geom;
    aero = disc.aero;
    S    = g.S_ref;
    W_TO = result.W_TO;
    W_end = W_TO - result.final_pass.W_fuel_burned;   % weight after the mission fuel is burned

    % name, altitude [ft], Mach
    conds = { ...
        'Cruise M0.7, 30 kft',   30000, 0.70; ...
        'Dash M0.8, 30 kft',     30000, 0.80; ...
        'Dash M0.9, 30 kft',     30000, 0.90; ...
        'Dash M0.8, sea level',      0, 0.80; ...
        'Loiter M0.45, 10 kft',  10000, 0.45 };
    n = size(conds, 1);
    colors = lines(n);
    con = struct('stores_present', true);

    fig = figure('Name', 'Drag polar', 'Color', 'w', 'Position', [100 100 1350 450]); %#ok<NASGU>
    ax1 = subplot(1,3,1); hold(ax1, 'on'); grid(ax1, 'on');
    ax2 = subplot(1,3,2); hold(ax2, 'on'); grid(ax2, 'on');
    ax3 = subplot(1,3,3); hold(ax3, 'on'); grid(ax3, 'on');

    fprintf('\n=== Drag polar (converged aircraft, S_ref = %.1f ft^2, AR = %.2f) ===\n', S, g.AR);
    fprintf('%-24s %8s %8s %6s %8s %9s | %7s %7s %6s | %7s %6s\n', ...
        'condition', 'CD0', 'K', 'e', 'L/Dmax', 'CL@L/Dmax', 'CL@WTO', 'CD@WTO', 'L/D', 'CL@Wend', 'L/D');

    csv = table();
    stack = zeros(n, 4);          % CD0, CDi, CDwave, CDstores at W_TO  [drag counts]
    labels = cell(n, 1);

    for k = 1:n
        name = conds{k,1};  alt = conds{k,2};  M = conds{k,3};
        state = get_state(alt, M);
        P = aero.drag_polar(state, con);              % CL, CD, LD, CD0, K1, e, LD_max ...
        labels{k} = sprintf('%s', name);

        plot(ax1, P.CD, P.CL, '-', 'LineWidth', 1.6, 'Color', colors(k,:), 'DisplayName', name);
        plot(ax2, P.CL, P.LD, '-', 'LineWidth', 1.6, 'Color', colors(k,:), 'DisplayName', name);

        % best L/D point
        [~, ib] = max(P.LD);
        plot(ax1, P.CD(ib), P.CL(ib), 's', 'Color', colors(k,:), 'MarkerFaceColor', 'w', 'HandleVisibility', 'off');
        plot(ax2, P.CL(ib), P.LD(ib), 's', 'Color', colors(k,:), 'MarkerFaceColor', 'w', 'HandleVisibility', 'off');

        % operating points in level flight at start and end of mission weight
        CL_to  = W_TO  / (state.q * S);
        CL_end = W_end / (state.q * S);
        CD_to  = aero.compute_CD_at(state, CL_to,  con);
        CD_end = aero.compute_CD_at(state, CL_end, con);
        plot(ax1, CD_to,  CL_to,  'o', 'Color', colors(k,:), 'MarkerFaceColor', colors(k,:), 'HandleVisibility', 'off');
        plot(ax1, CD_end, CL_end, '^', 'Color', colors(k,:), 'MarkerFaceColor', colors(k,:), 'HandleVisibility', 'off');
        plot(ax2, CL_to,  CL_to/CD_to,   'o', 'Color', colors(k,:), 'MarkerFaceColor', colors(k,:), 'HandleVisibility', 'off');
        plot(ax2, CL_end, CL_end/CD_end, '^', 'Color', colors(k,:), 'MarkerFaceColor', colors(k,:), 'HandleVisibility', 'off');

        fprintf('%-24s %8.4f %8.4f %6.3f %8.2f %9.3f | %7.3f %7.4f %6.2f | %7.3f %6.2f\n', ...
            name, P.CD0, P.K1, P.e, P.LD_max, P.CL_at_LDmax, ...
            CL_to, CD_to, CL_to/CD_to, CL_end, CL_end/CD_end);

        % drag breakdown at the W_TO operating point
        e_   = aero.oswald_efficiency();
        stack(k,1) = aero.cd0_buildup(state);
        stack(k,2) = CL_to^2 / (pi * g.AR * e_);
        stack(k,3) = aero.wave_drag(state, CL_to);
        stack(k,4) = aero.store_drag(g.n_stores);

        % collect for csv
        T = table(repmat({name}, numel(P.CL), 1), P.CL(:), P.CD(:), P.LD(:), ...
            'VariableNames', {'condition', 'CL', 'CD', 'LD'});
        csv = [csv; T]; %#ok<AGROW>
    end

    xlabel(ax1, 'C_D');  ylabel(ax1, 'C_L');  title(ax1, 'Drag polar');
    xlabel(ax2, 'C_L');  ylabel(ax2, 'L/D');  title(ax2, 'Lift-to-drag ratio');
    legend(ax1, 'Location', 'southeast', 'FontSize', 8);
    text(ax1, 0.02, 0.97, {'o  at W_{TO}', '^  at W_{TO} minus fuel burned', 's  L/D_{max}'}, ...
        'Units', 'normalized', 'VerticalAlignment', 'top', 'FontSize', 8);

    bar(ax3, stack * 1e4, 'stacked');
    set(ax3, 'XTick', 1:n, 'XTickLabel', labels, 'XTickLabelRotation', 30, 'FontSize', 8);
    ylabel(ax3, 'drag counts (C_D \times 10^4) at W_{TO}');
    title(ax3, 'Drag breakdown at W_{TO}');
    legend(ax3, {'CD0', 'induced', 'wave', 'stores'}, 'Location', 'northwest', 'FontSize', 8);

    writetable(csv, 'drag_polar_X1.csv');
    fprintf('Polar data written to drag_polar_X1.csv\n');

    % CD0 by component at the cruise condition, with a sum check
    cd0_components(disc, get_state(conds{1,2}, conds{1,3}));
end