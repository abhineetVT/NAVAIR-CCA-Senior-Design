function cd0_components(disc, state)
%CD0_COMPONENTS  Parasite-drag build-up by component, mirroring CcaAero.cd0_buildup.
%   Replicates the formulas so each part can be reported; the last line checks
%   that the parts add up to aero.cd0_buildup (if not, the class changed and
%   this function needs the same edit).
    g = disc.geom;  aero = disc.aero;  M = state.mach;

    Cf = @(Re) 0.455 / ((log10(Re))^2.58 * (1 + 0.144*M^2)^0.65);
    FF_fus = 1 + 60/(g.fineness_ratio^3) + g.fineness_ratio/400;

    f.wing = Cf(state.atm.reynolds(g.MAC))    * aero.FF_wing    * aero.Q_interference * g.S_wet_wing;
    f.fus  = Cf(state.atm.reynolds(g.l_fus))  * FF_fus          * aero.Q_interference * g.S_wet_fuselage;
    f.nac  = Cf(state.atm.reynolds(g.l_nacelle)) * aero.FF_nacelle * aero.Q_interference * g.S_wet_nacelle;
    if g.tail_type == "none"
        f.tail = 0;
    else
        f.tail = Cf(state.atm.reynolds(max(g.MAC*0.6, 1))) * aero.FF_tail * aero.Q_interference * ...
                 (g.S_wet_ht + g.S_wet_vt);
    end

    parts = [f.wing f.fus f.nac f.tail];
    names = {'wing', 'fuselage', 'nacelle / intakes', 'tails'};
    wet   = [g.S_wet_wing g.S_wet_fuselage g.S_wet_nacelle g.S_wet_ht + g.S_wet_vt];
    scale = (1 + aero.misc_drag_frac) / g.S_ref;       % to CD, including the misc allowance
    CD0_parts = parts * scale;

    fprintf('\n=== CD0 by component (M %.2f, %.0f ft) ===\n', M, state.alt);
    fprintf('%-20s %10s %12s %8s\n', 'component', 'S_wet ft^2', 'CD0 (counts)', '% of CD0');
    for i = 1:numel(parts)
        fprintf('%-20s %10.1f %12.1f %8.1f\n', names{i}, wet(i), CD0_parts(i)*1e4, 100*CD0_parts(i)/sum(CD0_parts));
    end
    fprintf('%-20s %10.1f %12.1f %8.1f\n', 'TOTAL', sum(wet), sum(CD0_parts)*1e4, 100);
    ref = aero.cd0_buildup(state);
    fprintf('check vs aero.cd0_buildup: %.5f vs %.5f (diff %.2e)\n', sum(CD0_parts), ref, sum(CD0_parts) - ref);
end